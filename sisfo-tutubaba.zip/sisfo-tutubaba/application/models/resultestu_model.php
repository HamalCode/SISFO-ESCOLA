<?php 
class resultestu_model extends CI_Model{
	public function fosai_dadus($limit, $start)
	{
		return $this->db->get('t_estudante', $limit, $start);
		
	}

	public function countAllestudante()
	{
		return $this->db->get('t_estudante')->num_rows();
	}
	public function foti_nre_estudante($nre)
	{
		$resultadu = $this->db->where('nre',$nre)->get('t_estudante');
		if($resultadu->num_rows() > 0){
			return $resultadu->result();
		}else{
			return false;
		}
   }
   public function insert_data($data,$table)
   {
   	$this->db->insert($table,$data);
   }
   public function update_data($where,$data,$table)
	{
		$this->db->where($where);
		$this->db->update($table,$data);
	}
	public function hamos_data($where,$table)
	{
		$this->db->where($where);
		$this->db->delete($table);
	}
	

}