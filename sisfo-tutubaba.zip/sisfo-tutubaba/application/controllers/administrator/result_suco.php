<?php 
class result_suco extends CI_Controller{
	public function index()
	{
		$data['t_suco'] = $this->posto_model->fosai_dadus('t_suco')->result();
	     $this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/result_suco',$data);
		$this->load->view('templates_administrator/footer');

	}
}