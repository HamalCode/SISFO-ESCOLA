<?php 
class municipio extends CI_Controller{
	public function index()
	{
		
		 $data['start'] = $this->uri->segment(4);
		$data['t_municipio']  =$this->municipio_model->fosai_dadus('t_municipio')->result();
		
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/municipio',$data);
		$this->load->view('templates_administrator/footer');
	}
	public function input()
	{
		$data = array(
			'id_municipio'	=>set_value('id_municipio'),
			'code'	        =>set_value('code'),
			'nrn_municipio'	=>set_value('nrn_municipio'),
		);
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/form_municipio',$data);
		$this->load->view('templates_administrator/footer');
	}
	
	public function asaun_input()
	{
		$this->_rules();
		if($this->form_validation->run() ==FALSE) {
			$this->input();
		}else{
			$data = array(
				'code'           =>$this->input->post('code',TRUE),
				'nrn_municipio'   =>$this->input->post('nrn_municipio',TRUE),
			);
			$this->municipio_model->input_dadus($data);
			$this->session->set_flashdata('mensagem','<div class="alert alert-succsess bg-success alert-dismissible fade show" role="alert">
					Dadus Municipio Susesu aumenta!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
			redirect('administrator/municipio');
		}

	}
	public function _rules()
	{
		$this->form_validation->set_rules('code','code','required',[
			'required' =>'Favor Prense Lista'
		]);
		$this->form_validation->set_rules('nrn_municipio','nrn_municipio','required',[
			'required' =>'Favor prense Lista'
		]);
	}
	public function update($id)
	{
		$where = array('id_municipio' => $id);
		$data['t_municipio']=$this->municipio_model->edit_data($where,'t_municipio')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/update_municipio',$data);
		$this->load->view('templates_administrator/footer');
	}
	public function asaun_update()
	{
		$id = $this->input->post('id_municipio');
		$code   = $this->input->post('code');
		$nrn_municipio = $this->input->post('nrn_municipio');

		$data = array(
			'code'      => $code,
			'nrn_municipio' => $nrn_municipio
		);

		$where = array(
			'id_municipio' =>$id
		);
		$this->municipio_model->update_data($where,$data,'t_municipio');
		$this->session->set_flashdata('mensagem','<div class="alert alert-success bg-success alert-dismissible fade show" role="alert">
					Dadus Municipio Susesu Update!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/municipio');

	}
	public function delete($id)
	{
		$where = array('id_municipio' => $id);
		$this->municipio_model->hamos_data($where, 't_municipio');
		$this->session->set_flashdata('mensagem','<div class="alert alert-danger alert-dismissible fade show" role="alert">
					Dadus Municipio Susesu Hamos!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/municipio');
	}

	public function print()
	{
		$data['t_municipio']= $this->municipio_model->fosai_dadus('t_municipio')->result();
        $this->load->view('administrator/print_municipio',$data);
	}

	public function pdf  (){
        $this->load->library('dompdf_gen');
        $data['t_municipio']=$this->municipio_model->fosai_dadus("t_municipio")->result();
        $this->load->view('administrator/relmunicipio_pdf',$data);

        $paper_size='A4';
        $orientation='landscape';
        $html=$this->output->get_output();
        $this->dompdf->set_paper($paper_size, $orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("lapor_mahasiswa.pdf", array('attachment'=>0));
     }
}