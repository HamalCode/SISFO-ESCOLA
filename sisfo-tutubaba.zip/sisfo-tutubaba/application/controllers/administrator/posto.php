<?php 
class posto extends CI_Controller{
	public function index()
	{
		$data['t_posto'] = $this->posto_model->fosai_dadus('t_posto')->result();
		$data['t_municipio'] = $this->posto_model->fosai_dadus('t_municipio')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/posto',$data);
		$this->load->view('templates_administrator/footer');

	}

	public function amenta_posto()
	{
		$data = array(
			'id'	     =>set_value('id'),
			'code_posto'	=>set_value('code_posto'),
			'code'	        =>set_value('code'),
			'nrn_posto'	=>set_value('nrn_posto'),
		);
		$data['t_municipio'] = $this->posto_model->fosai_dadus('t_municipio')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/form_posto',$data);
		$this->load->view('templates_administrator/footer');
	}

	public function asaun_amenta_posto()
	{
		$this->_rules();
		if($this->form_validation->run() == FALSE)
		{
			$this->amenta_posto();
		}else{

			$data =array (
				'code_posto'           =>$this->input->post('code_posto',TRUE),
				'code'              =>$this->input->post('code',TRUE),
				'nrn_posto'         =>$this->input->post('nrn_posto',TRUE),


			);
			$this->posto_model->insert_data($data,'t_posto');
			$this->session->set_flashdata('mensagem','<div class="alert alert-success alert-dismissible fade show" role="alert">
					Dadus Posto Susesu aumenta!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
			redirect('administrator/posto');
		}
	}

		public function _rules()
		{
			$this->form_validation->set_rules('code_posto','id ','required',['required' => 'id Sedauk Iha!']);
			$this->form_validation->set_rules('code','code','required',['required' => 'id mun Sedauk Iha!']);

  	$this->form_validation->set_rules('nrn_posto','naran Posto','required',['required' => 'naran Posto Sedauk Iha!']);

  	
		}

	public function update($id)
		{
			$where= array('id' => $id);
			$data['t_posto'] = $this->db->query("select * from t_posto pos, t_municipio mun where pos.code=mun.code and pos.id='$id'")->result();
			$data['t_municipio'] = $this->posto_model->fosai_dadus('t_municipio')->result();
			$data['t_posto']=$this->posto_model->edit_data($where,'t_posto')->result();
			$this->load->view('templates_administrator/header');
			$this->load->view('templates_administrator/sidebar');
			$this->load->view('administrator/update_posto',$data);
			$this->load->view('templates_administrator/footer');
		}

		public function asaun_update_posto()
		{
			
			if($this->form_validation->run()==FALSE)
			{
			$id                 =$this->input->post('id');
		    $code_posto         = $this->input->post('code_posto');
			$code               = $this->input->post('code');
			$nrn_posto          = $this->input->post('nrn_posto');
	

			$data = array(
			'code_posto'   	       =>$code_posto,
		    'code'	             =>$code,
			 'nrn_posto'	     =>$nrn_posto
			
		      );

			$where= array(
				'id'  =>$id
			);

			$this->posto_model->update_data($where,$data,'t_posto');
		    $this->session->set_flashdata('mensagem','<div class="alert alert-success alert-dismissible fade show" role="alert">
					Dadus  Posto Susesu Update!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/posto');
		}
	}
		public function delete($id)
	{
		$where = array('id' => $id);
		$this->posto_model->hamos_data($where, 't_posto');
		$this->session->set_flashdata('mensagem','<div class="alert alert-danger alert-dismissible fade show" role="alert">
					Dadus Posto Susesu Hamos!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/posto');
	}
	public function print()
	{
		$data['t_posto']= $this->posto_model->fosai_dadus('t_posto')->result();
        $this->load->view('administrator/print_posto',$data);
	}
	public function pdf  (){
        $this->load->library('dompdf_gen');
        $data['t_posto']=$this->posto_model->fosai_dadus("t_posto")->result();
        $this->load->view('administrator/relposto_pdf',$data);

        $paper_size='A4';
        $orientation='landscape';
        $html=$this->output->get_output();
        $this->dompdf->set_paper($paper_size, $orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("lapor_mahasiswa.pdf", array('attachment'=>0));
     }

}