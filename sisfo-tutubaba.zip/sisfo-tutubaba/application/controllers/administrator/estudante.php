<?php 
class estudante extends CI_Controller{
	public function index()
	{
		//pagination
		$this->load->library('pagination');
		//config
		$config['base_url']= 'http://localhost/sisfo-tutubaba/administrator/estudante/index';
		$config['total_rows'] = $this->estudante_model->countAllestudante();
		// var_dump($config['total_rows']); die; cek total datta table.
		$config['per_page'] = 8;
		$config['num_links']=5;
		//style
		$config['full_tag_open']='<nav"><ul class="pagination justify-content-center">';
		$config['full_tag_close']=' </ul></nav>';

		$config['first_link'] ='First';
		$config['first_tag_open']=' <li class="page-item">';
		$config['first_tag_close']=' </li>';

		$config['last_link'] ='Last';
		$config['last_tag_open']=' <li class="page-item">';
		$config['last_tag_close']=' </li>';
		
		$config['next_link'] ='&raquo';
		$config['next_tag_open']=' <li class="page-item">';
		$config['next_tag_close']=' </li>';

		$config['prev_link'] ='&laquo';
		$config['prev_tag_open']=' <li class="page-item">';
		$config['prev_tag_close']=' </li>';

		$config['cur_tag_open']=' <li class="page-item active"><a class="page-link" href="#">';
		$config['cur_tag_close']='</a> </li>';

		$config['num_tag_open']=' <li class="page-item ">';
		$config['num_tag_close']=' </li>';

		// Produces: class="myclass"
       $config['attributes'] = array('class' => 'page-link');

		//initialize
		$this->pagination->initialize($config);
		
	
       $data['start'] = $this->uri->segment(4);
		$data['t_estudante']  =$this->estudante_model->fosai_dadus($config['per_page'], $data['start'])->result();
		$data['t_esc_ante'] = $this->escante_model->fosai_dadus('t_esc_ante')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/estudante',$data);
		$this->load->view('templates_administrator/footer');
		
	}
	public function detail($id)
	{
		$data['detail']= $this->estudante_model->foti_id_estudante($id);
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/estudante_detail',$data);
		$this->load->view('templates_administrator/footer');
	}

	
	
	public function amenta_estudante()
	{
		//pagination
		$this->load->library('pagination');
		//config
		$config['base_url']= 'http://localhost/sisfo-tutubaba/administrator/estudante/index';
		$config['total_rows'] = $this->estudante_model->countAllestudante();
		// var_dump($config['total_rows']); die; cek total datta table.
		$config['per_page'] = 8;
		$config['num_links']=5;
		//style
		$config['full_tag_open']='<nav"><ul class="pagination justify-content-center">';
		$config['full_tag_close']=' </ul></nav>';

		$config['first_link'] ='First';
		$config['first_tag_open']=' <li class="page-item">';
		$config['first_tag_close']=' </li>';

		$config['last_link'] ='Last';
		$config['last_tag_open']=' <li class="page-item">';
		$config['last_tag_close']=' </li>';
		
		$config['next_link'] ='&raquo';
		$config['next_tag_open']=' <li class="page-item">';
		$config['next_tag_close']=' </li>';

		$config['prev_link'] ='&laquo';
		$config['prev_tag_open']=' <li class="page-item">';
		$config['prev_tag_close']=' </li>';

		$config['cur_tag_open']=' <li class="page-item active"><a class="page-link" href="#">';
		$config['cur_tag_close']='</a> </li>';

		$config['num_tag_open']=' <li class="page-item ">';
		$config['num_tag_close']=' </li>';

		// Produces: class="myclass"
       $config['attributes'] = array('class' => 'page-link');
		$data['start'] = $this->uri->segment(4);
		$data['t_esc_ante'] = $this->escante_model->fosai_dadus('t_esc_ante')->result();
		$data['t_municipio']  =$this->municipio_model->fosai_dadus($config['per_page'], $data['start'])->result();
		$data['t_posto'] = $this->posto_model->fosai_dadus('t_posto')->result();
		$data['t_suco'] = $this->suco_model->fosai_dadus('t_suco')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/form_estudante',$data);
		$this->load->view('templates_administrator/footer');
	}
	public function asaun_amenta_estudante()
	{
		$this->_rules();
		if($this->form_validation->run()==FALSE){
			$this->amenta_estudante();
		}else{
			$nre                               =$this->input->post('nre');
			$code_escante                        =$this->input->post('code_escante');
			$nrn_estudante                     =$this->input->post('nrn_estudante');
			$sexo                              =$this->input->post('sexo');
			$code                                 =$this->input->post('code');
			$code_posto                          =$this->input->post('code_posto');
			$code_suco                           =$this->input->post('code_suco');
			$inan                              =$this->input->post('inan');
			$aman                              =$this->input->post('aman');		
			$reli                              =$this->input->post('reli');
			$hela_fatin                        =$this->input->post('hela_fatin');
			$no_tfn                            =$this->input->post('no_tfn');
			$obs                               =$this->input->post('obs');
			$foto                              =$_FILES['foto'];
			if ($foto=''){}else{
				$config['upload_path'] ='./assets/uploads';
				$config['allowed_types'] = 'jpg|png|jpeg|gif';

				$this->load->library('upload',$config);
				if(!$this->upload->do_upload('foto')){
					echo "faila upload";die();
				}else{
					$foto=$this->upload->data('file_name');
				}
			}


		
		$data = array(
			'nre'                                    =>$nre,
			'code_escante'							 =>$code_escante,
			'nrn_estudante'                          =>$nrn_estudante,
			'sexo'                                   =>$sexo,
			'code'                                   =>$code,
			'code_posto'                              =>$code_posto,
			'code_suco'                               =>$code_suco,
			'inan'                                   =>$inan,
			'aman'							         =>$aman,
			'reli'                                   =>$reli,
			'hela_fatin'                             =>$hela_fatin,
			'no_tfn'                                 =>$no_tfn,
			'obs'									 =>$obs,
			'foto'                                   =>$foto
			
		);
		$this->estudante_model->insert_data($data,'t_estudante');
					$this->session->set_flashdata('mensagem','<div class="alert alert-success alert-dismissible fade show" role="alert">
					Dadus Estudante Susesu aumenta!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
			redirect('administrator/estudante');
	}
  }
  public function _rules()
  {
  	$this->form_validation->set_rules('nre','Nre','required',['required' => 'NRE Sedauk Iha!']);

  	$this->form_validation->set_rules('code_escante','Naran Escante','required',['required' => 'Naran Sedauk Iha!']);

  	$this->form_validation->set_rules('nrn_estudante','naran completo','required',['required' => 'Naran Sedauk Iha!']);
  	$this->form_validation->set_rules('sexo','sexo','required',['required' => 'Sexo Sedauk Iha!']);
  	$this->form_validation->set_rules('code','Municipio','required',['required' => 'Municipio Sedauk Iha!']);
  	$this->form_validation->set_rules('code_posto','Posto','required',['required' => 'Posto Adm Sedauk Iha!']);
  	$this->form_validation->set_rules('code_suco','Suco','required',['required' => 'Suco Sedauk Iha!']);
  	$this->form_validation->set_rules('inan','naran inan','required',['required' => 'Naran inan Sedauk  Iha!']);

  	  	$this->form_validation->set_rules('aman','naran aman','required',['required' => 'Naran aman Sedauk  Iha!']);

  	  	$this->form_validation->set_rules('reli','naran reli','required',['required' => 'Naran reli Sedauk  Iha!']);

  	$this->form_validation->set_rules('hela_fatin','hela fatin','required',['required' => 'Hela Fatin Sedauk Iha!']);

  	$this->form_validation->set_rules('no_tfn','no_tfn','required',['required' => 'No.Tfn Sedauk Iha!']);

   $this->form_validation->set_rules('obs','obs','required',['required' => 'Observasaun Sedauk Hakerek!']);
  }
  public function update($id)
	{

		$where= array('id' => $id);
	
		$data['t_estudante'] = $this->db->query("select * from t_estudante est, t_esc_ante esc where est.code_escante=esc.code_escante and est.id='$id'")->result();
		$data['t_estudante'] = $this->db->query("select * from t_estudante est, t_municipio mun where est.code=mun.code and est.id='$id'")->result();
		$data['t_estudante'] = $this->db->query("select * from t_estudante est, t_posto pos where est.code_posto=pos.code_posto and est.id='$id'")->result();
	$data['t_estudante'] = $this->db->query("select * from t_estudante est, t_suco suc where est.code_suco=suc.code_suco and est.id='$id'")->result();	



		// $this->pagination->initialize($config);
		$config['attributes'] = array('class' => 'page-link');
		$data['start'] = $this->uri->segment(4);
		// $data['t_estudante']  =$this->estudante_model->fosai_dadus($config['per_page'], $data['start'])->result();
		$data['t_esc_ante'] = $this->escante_model->fosai_dadus('t_esc_ante')->result();
		$data['t_municipio'] = $this->municipio_model->fosai_dadus('t_municipio')->result();
		$data['t_posto'] = $this->posto_model->fosai_dadus('t_posto')->result();
		$data['t_suco'] = $this->suco_model->fosai_dadus('t_suco')->result();
		$data['detail']      = $this->estudante_model->foti_id_estudante($id);
		
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/update_estudante',$data);
		$this->load->view('templates_administrator/footer');
	}
	public function asaun_update_estudante()
	{
		$this->_rules();
		if($this->form_validation->run()== FALSE)
		{
			$this->update();
		}else{
			$id                              =$this->input->post('id');
		    $nre                              =$this->input->post('nre');
			$code_escante                       =$this->input->post('code_escante');
			$nrn_estudante                     =$this->input->post('nrn_estudante');
			$sexo                              =$this->input->post('sexo');
			$code                                =   $this->input->post('code');
			$code_posto                         =$this->input->post('code_posto');
			$code_suco                          =$this->input->post('code_suco');
			$inan                              =$this->input->post('inan');
			$aman                              =$this->input->post('aman');		
			$reli                              =$this->input->post('reli');
			$hela_fatin                        =$this->input->post('hela_fatin');
			$no_tfn                            =$this->input->post('no_tfn');
			$obs                               =$this->input->post('obs');
		      $foto                            =$_FILES['userfile']['name'];
		if ($foto){
				$config['upload_path'] ='./assets/uploads';
				$config['allowed_types'] = 'jpg|png|jpeg|gif';

				$this->load->library('upload',$config);
				if($this->upload->do_upload('userfile')){
					$userfile = $this->upload->data('file_name');
					$this->db->set('foto', $userfile);
				}else{
					echo "Upload Faila";
				}
			}
			$data = array(
			'nre'                                    =>$nre,
			'code_escante'							 =>$code_escante,
			'nrn_estudante'                          =>$nrn_estudante,
			'sexo'                                   =>$sexo,
			'code'                                   =>$code,
			'code_posto'                              =>$code_posto,
			'code_suco'                               =>$code_suco,
			'inan'                                   =>$inan,
			'aman'							         =>$aman,
			'reli'                                   =>$reli,
			'hela_fatin'                             =>$hela_fatin,
			'no_tfn'                                 =>$no_tfn,
			'obs'									 =>$obs
			
			
		);
			$where = array(
				'id' =>$id
			);
		$this->estudante_model->update_data($where,$data,'t_estudante');
		$this->session->set_flashdata('mensagem','<div class="alert alert-success alert-dismissible fade show" role="alert">
					Dadus Estudante Susesu Amenta!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/estudante');
		}
		
	}

	public function delete($id)
	{
		$where = array('id' => $id);
		$this->estudante_model->hamos_data($where, 't_estudante');
		$this->session->set_flashdata('mensagem','<div class="alert alert-danger alert-dismissible fade show" role="alert">
					Dadus Estudante Susesu Hamos!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/estudante');
		echo 'Deleted successfully.';
	}
	public function print()
	{
		$data['t_estudante']= $this->escante_model->fosai_dadus('t_estudante')->result();
        $this->load->view('administrator/print_estudante',$data);
	}

	public function pdf  (){
        $this->load->library('dompdf_gen');
        $data['t_estudante']=$this->escante_model->fosai_dadus("t_estudante")->result();
        $this->load->view('administrator/relatorio_pdf',$data);

        $paper_size='A4';
        $orientation='landscape';
        $html=$this->output->get_output();
        $this->dompdf->set_paper($paper_size, $orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("lapor_mahasiswa.pdf", array('attachment'=>0));
     }
}
