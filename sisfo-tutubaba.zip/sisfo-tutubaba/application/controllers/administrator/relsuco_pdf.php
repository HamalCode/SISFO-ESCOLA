<center><H2>RELATORIO SUCO</H2></center><br><hr><html>
<head><link rel="stylesheet" type="text/css" href="style.css">
	<title></title>
</head><body>
	<table align="center"cellspacing='0' border="1" width="70%">
	
			<tr>
			<th class="" bgcolor="silver">NO</th>
	  		<th class="text-center" bgcolor="silver">ID SUCO</th>
	  		<th class="text-center" bgcolor="silver">NARAN SUCO</th>		
			</tr>
		</tr>
			<?php 
		$no=1;
		foreach ($t_suco as $suc) : ?>
			<tr>
				    <td width="20px"><?php echo $no++ ?></td>
	  	 	<td class="text-center" width="50px"><?php echo $suc->id_suco?></td>
	  	 	<td class="text-center" width="50px"><?php echo $suc->nrn_suco?></td>							
			</tr>
		<?php endforeach; ?>
		
	</table>
</body></html>