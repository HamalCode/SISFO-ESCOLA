<?php 
class result_estudante extends CI_Controller{
	public function index()
	{
		//pagination
		$this->load->library('pagination');
		//config
		$config['base_url']= 'http://localhost/sisfo-tutubaba/administrator/result_estudante/index';
		$config['total_rows'] = $this->resultestu_model->countAllestudante();
		// var_dump($config['total_rows']); die; cek total datta table.
		$config['per_page'] = 8;
		$config['num_links']=5;
		//style
		$config['full_tag_open']='<nav"><ul class="pagination justify-content-center">';
		$config['full_tag_close']=' </ul></nav>';

		$config['first_link'] ='First';
		$config['first_tag_open']=' <li class="page-item">';
		$config['first_tag_close']=' </li>';

		$config['last_link'] ='Last';
		$config['last_tag_open']=' <li class="page-item">';
		$config['last_tag_close']=' </li>';
		
		$config['next_link'] ='&raquo';
		$config['next_tag_open']=' <li class="page-item">';
		$config['next_tag_close']=' </li>';

		$config['prev_link'] ='&laquo';
		$config['prev_tag_open']=' <li class="page-item">';
		$config['prev_tag_close']=' </li>';

		$config['cur_tag_open']=' <li class="page-item active"><a class="page-link" href="#">';
		$config['cur_tag_close']='</a> </li>';

		$config['num_tag_open']=' <li class="page-item ">';
		$config['num_tag_close']=' </li>';

		// Produces: class="myclass"
       $config['attributes'] = array('class' => 'page-link');

		//initialize
		$this->pagination->initialize($config);
		

       $data['start'] = $this->uri->segment(4);
		$data['t_estudante']  =$this->estudante_model->fosai_dadus($config['per_page'], $data['start'])->result();
		$data['t_esc_ante'] = $this->escante_model->fosai_dadus('t_esc_ante')->result();
		$data['t_municipio']  =$this->municipio_model->fosai_dadus($config['per_page'], $data['start'])->result();
		$data['t_posto'] = $this->posto_model->fosai_dadus('t_posto')->result();
		$data['t_suco'] = $this->suco_model->fosai_dadus('t_suco')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/result_estudante',$data);
		$this->load->view('templates_administrator/footer');
		
	}
	// public function detail($nre)
	// {
	// 	$data['detail']= $this->prosesu_model->foti_nre_estudante($nre);
	// 	$this->load->view('templates_administrator/header');
	// 	$this->load->view('templates_administrator/sidebar');
	// 	$this->load->view('administrator/prosesu',$data);
	// 	$this->load->view('templates_administrator/footer');
	// }

	
	
	public function amenta_estudante()
	{
		//pagination
		$this->load->library('pagination');
		//config
		$config['base_url']= 'http://localhost/sisfo-tutubaba/administrator/result_estudante/index';
		$config['total_rows'] = $this->resultestu_model->countAllestudante();
		// var_dump($config['total_rows']); die; cek total datta table.
		$config['per_page'] = 8;
		$config['num_links']=5;
		//style
		$config['full_tag_open']='<nav"><ul class="pagination justify-content-center">';
		$config['full_tag_close']=' </ul></nav>';

		$config['first_link'] ='First';
		$config['first_tag_open']=' <li class="page-item">';
		$config['first_tag_close']=' </li>';

		$config['last_link'] ='Last';
		$config['last_tag_open']=' <li class="page-item">';
		$config['last_tag_close']=' </li>';
		
		$config['next_link'] ='&raquo';
		$config['next_tag_open']=' <li class="page-item">';
		$config['next_tag_close']=' </li>';

		$config['prev_link'] ='&laquo';
		$config['prev_tag_open']=' <li class="page-item">';
		$config['prev_tag_close']=' </li>';

		$config['cur_tag_open']=' <li class="page-item active"><a class="page-link" href="#">';
		$config['cur_tag_close']='</a> </li>';

		$config['num_tag_open']=' <li class="page-item ">';
		$config['num_tag_close']=' </li>';

		// Produces: class="myclass"
       $config['attributes'] = array('class' => 'page-link');
		$data['start'] = $this->uri->segment(4);
		$data['t_esc_ante'] = $this->escante_model->fosai_dadus('t_esc_ante')->result();
		$data['t_municipio']  =$this->municipio_model->fosai_dadus($config['per_page'], $data['start'])->result();
		$data['t_Posto'] = $this->posto_model->fosai_dadus('t_posto')->result();
		$data['t_suco'] = $this->suco_model->fosai_dadus('t_suco')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		// $this->load->view('administrator/form_estudante',$data);
		$this->load->view('templates_administrator/footer');
	}
	public function asaun_amenta_estudante()
	{
		$this->_rules();
		if($this->form_validation->run()==FALSE){
			$this->amenta_estudante();
		}else{
			$nre                               =$this->input->post('nre');
			$id_escante                        =$this->input->post('id_escante');
			$nrn_estudante                     =$this->input->post('nrn_estudante');
			$sexo                              =$this->input->post('sexo');
			$code                                =$this->input->post('code');
			$id_posto                          =$this->input->post('id_posto');
			$id_suco                           =$this->input->post('id_suco');
			$inan                              =$this->input->post('inan');
			$aman                              =$this->input->post('aman');		
			$reli                              =$this->input->post('reli');
			$hela_fatin                        =$this->input->post('hela_fatin');
			$no_tfn                            =$this->input->post('no_tfn');
			$obs                               =$this->input->post('obs');
			$foto                              =$_FILES['foto'];
			if ($foto=''){}else{
				$config['upload_path'] ='./assets/uploads';
				$config['allowed_types'] = 'jpg|png|jpeg|gif';

				$this->load->library('upload',$config);
				if(!$this->upload->do_upload('foto')){
					echo "faila upload";die();
				}else{
					$foto=$this->upload->data('file_name');
				}
			}


		
		$data = array(
			'nre'                                    =>$nre,
			'id_escante'							 =>$id_escante,
			'nrn_estudante'                          =>$nrn_estudante,
			'sexo'                                   =>$sexo,
			'code'                                  =>$code,
			'id_posto'                              =>$id_posto,
			'id_suco'                               =>$id_suco,
			'inan'                                   =>$inan,
			'aman'							         =>$aman,
			'reli'                                   =>$reli,
			'hela_fatin'                             =>$hela_fatin,
			'no_tfn'                                 =>$no_tfn,
			'obs'									 =>$obs,
			'foto'                                   =>$foto
			
		);
		$this->estudante_model->insert_data($data,'t_estudante');
					$this->session->set_flashdata('mensagem','<div class="alert alert-success alert-dismissible fade show" role="alert">
					Dadus Estudante Susesu aumenta!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
			redirect('administrator/estudante');
	}
  }
  public function _rules()
  {
  	$this->form_validation->set_rules('nre','Nre','required',['required' => 'NRE Sedauk Iha!']);

  	$this->form_validation->set_rules('nrn_escante','Naran Escante','required',['required' => 'Naran Sedauk Iha!']);

  	$this->form_validation->set_rules('nrn_estudante','naran completo','required',['required' => 'Naran Sedauk Iha!']);
  	$this->form_validation->set_rules('sexo','sexo','required',['required' => 'Sexo Sedauk Iha!']);
  	$this->form_validation->set_rules('code','Municipio','required',['required' => 'Municipio Sedauk Iha!']);
  	$this->form_validation->set_rules('id_posto','Posto','required',['required' => 'Posto Adm Sedauk Iha!']);
  	$this->form_validation->set_rules('id_suco','Suco','required',['required' => 'Suco Sedauk Iha!']);
  	$this->form_validation->set_rules('inan','naran inan','required',['required' => 'Naran inan Sedauk  Iha!']);

  	  	$this->form_validation->set_rules('aman','naran aman','required',['required' => 'Naran aman Sedauk  Iha!']);

  	  	$this->form_validation->set_rules('reli','naran reli','required',['required' => 'Naran reli Sedauk  Iha!']);

  	$this->form_validation->set_rules('hela_fatin','hela fatin','required',['required' => 'Hela Fatin Sedauk Iha!']);

  	$this->form_validation->set_rules('no_tfn','no_tfn','required',['required' => 'No.Tfn Sedauk Iha!']);

   $this->form_validation->set_rules('obs','obs','required',['required' => 'Observasaun Sedauk Hakerek!']);
  }

}
