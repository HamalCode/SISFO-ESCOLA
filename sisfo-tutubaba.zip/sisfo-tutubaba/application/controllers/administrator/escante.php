<?php 
class escante extends CI_Controller{
	public function index()
	{
		$data['t_esc_ante'] = $this->escante_model->fosai_dadus('t_esc_ante')->result();
		$data['t_suco'] = $this->suco_model->fosai_dadus('t_suco')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/escante',$data);
		$this->load->view('templates_administrator/footer');

	}

	public function amenta_escante()
	{
		$data = array(
			'id'	     =>set_value('id'),
			'code_escante'	=>set_value('code_escante'),
			'code_suco'	        =>set_value('code_suco'),
			'nrn_escante'	=>set_value('nrn_escante'),
		);
		$data['t_suco'] = $this->posto_model->fosai_dadus('t_suco')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/form_escante',$data);
		$this->load->view('templates_administrator/footer');
	}

	public function asaun_amenta_escante()
	{
		$this->_rules();
		if($this->form_validation->run() == FALSE)
		{
			$this->amenta_escante();
		}else{

			$data =array (
				'code_escante'           =>$this->input->post('code_escante',TRUE),
				'code_suco'              =>$this->input->post('code_suco',TRUE),
				'nrn_escante'         =>$this->input->post('nrn_escante',TRUE),

			);
			$this->escante_model->insert_data($data,'t_esc_ante');
			$this->session->set_flashdata('mensagem','<div class="alert alert-success alert-dismissible fade show" role="alert">
					Dadus Escola Anterior Susesu aumenta!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
			redirect('administrator/escante');
		}
	}

		public function _rules()
		{
			$this->form_validation->set_rules('code_escante','id ','required',['required' => 'id Sedauk Iha!']);
			$this->form_validation->set_rules('code_suco','id esc','required',['required' => 'id esc Sedauk Iha!']);

  	$this->form_validation->set_rules('nrn_escante','naran Escante','required',['required' => 'naran Escante Sedauk Iha!']);

  	
		}

	public function update($id)
		{
			$where= array('id' => $id);
			$data['t_esc_ante'] = $this->db->query("select * from t_esc_ante esc, t_suco suc where esc.code_suco=suc.code_suco and esc.id='$id'")->result();
			$data['t_suco'] = $this->posto_model->fosai_dadus('t_suco')->result();
			$data['t_municipio']=$this->escante_model->edit_data($where,'t_esc_ante')->result();
			$this->load->view('templates_administrator/header');
			$this->load->view('templates_administrator/sidebar');
			$this->load->view('administrator/update_escante',$data);
			$this->load->view('templates_administrator/footer');
		}

		public function asaun_update_escante()
		{
			
			if($this->form_validation->run()==FALSE)
			{
		    $id        = $this->input->post('id');
			$code_escante        = $this->input->post('code_escante');
			$code_suco           = $this->input->post('code_suco');
			$nrn_escante        = $this->input->post('nrn_escante');
	

			 $data = array(
	  	     
		  	'code_escante'   	    =>$code_escante,
			'code_suco'	        =>$code_suco,
		   'nrn_escante'	    =>$nrn_escante
		      );

			 $where= array(
				'id'  =>$id
		 );

			$this->escante_model->update_data($where,$data,'t_esc_ante');
		    $this->session->set_flashdata('mensagem','<div class="alert alert-success alert-dismissible fade show" role="alert">
					Dadus  Escola Anterior Susesu Update!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/escante');
		}
	}
		public function delete($id)
	{
		$where = array('id' => $id);
		$this->escante_model->hamos_data($where, 't_esc_ante');
		$this->session->set_flashdata('mensagem','<div class="alert alert-danger alert-dismissible fade show" role="alert">
					Dadus Escante Susesu Hamos!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/escante');
	}
	public function print()
	{
		$data['t_esc_ante']= $this->escante_model->fosai_dadus('t_esc_ante')->result();
        $this->load->view('administrator/print_escante',$data);
	}
	public function pdf  (){
        $this->load->library('dompdf_gen');
        $data['t_esc_ante']=$this->posto_model->fosai_dadus("t_esc_ante")->result();
        $this->load->view('administrator/relescante_pdf',$data);

        $paper_size='A4';
        $orientation='landscape';
        $html=$this->output->get_output();
        $this->dompdf->set_paper($paper_size, $orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("lapor_mahasiswa.pdf", array('attachment'=>0));
     }

}