<?php 
class result_escante extends CI_Controller{
	public function index()
	{
		$data['t_esc_ante'] = $this->escante_model->fosai_dadus('t_esc_ante')->result();
		$data['t_suco'] = $this->suco_model->fosai_dadus('t_suco')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/result_escante',$data);
		$this->load->view('templates_administrator/footer');

	}
}