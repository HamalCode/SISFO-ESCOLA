<?php 
class suco extends CI_Controller{
	public function index()
	{
		$data['t_suco'] = $this->posto_model->fosai_dadus('t_suco')->result();
		$data['t_posto'] = $this->posto_model->fosai_dadus('t_posto')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/suco',$data);
		$this->load->view('templates_administrator/footer');

	}

	public function amenta_suco()
	{
		$data = array(
			'id'	     =>set_value('id'),
			'code_suco'	=>set_value('code_suco'),
			'code_posto' =>set_value('code_posto'),
			'nrn_suco'	=>set_value('nrn_suco'),
		);
		$data['t_posto'] = $this->suco_model->fosai_dadus('t_posto')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/form_suco',$data);
		$this->load->view('templates_administrator/footer');
	}

	public function asaun_amenta_suco()
	{
		$this->_rules();
		if($this->form_validation->run() == FALSE)
		{
			$this->amenta_suco();
		}else{

			$data =array (
				'code_suco'           =>$this->input->post('code_suco',TRUE),
				'code_posto'              =>$this->input->post('code_posto',TRUE),
				'nrn_suco'         =>$this->input->post('nrn_suco',TRUE),


			);
			$this->posto_model->insert_data($data,'t_suco');
			$this->session->set_flashdata('mensagem','<div class="alert alert-success alert-dismissible fade show" role="alert">
					Dadus Posto Susesu aumenta!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
			redirect('administrator/suco');
		}
		
	}

		public function _rules()
		{
			$this->form_validation->set_rules('code_suco','id suco','required',['required' => 'id suco Sedauk Iha!']);

			$this->form_validation->set_rules('code_posto','id posto ','required',['required' => 'id Sedauk Iha!']);
			

  	      $this->form_validation->set_rules('nrn_suco','naran Suco','required',['required' => 'naran Suco Sedauk Iha!']);

  	
		}

	public function update($id)
		{
			$where= array('id' => $id);
			$data['t_suco'] = $this->db->query("select * from t_suco suc, t_posto pos where suc.code_posto=pos.code_posto and suc.id='$id'")->result();
			$data['t_posto'] = $this->suco_model->fosai_dadus('t_posto')->result();
			$data['t_suco']=$this->suco_model->edit_data($where,'t_suco')->result();
			$this->load->view('templates_administrator/header');
			$this->load->view('templates_administrator/sidebar');
			$this->load->view('administrator/update_suco',$data);
			$this->load->view('templates_administrator/footer');
		}

		public function asaun_update_suco()
		{
			
			if($this->form_validation->run()==FALSE)
			{
				$id                 =$this->input->post('id');
		    $code_suco        = $this->input->post('code_suco');
			$code_posto        = $this->input->post('code_posto');
			$nrn_suco      = $this->input->post('nrn_suco');
	

			$data = array(
			    'code_suco'	    =>$code_suco,
				'code_posto'   	=>$code_posto,
				'nrn_suco'	    =>$nrn_suco
			
		      );

		 $where= array(
		 	'id'  =>$id
			 );

			$this->suco_model->update_data($where,$data,'t_suco');
		    $this->session->set_flashdata('mensagem','<div class="alert alert-success alert-dismissible fade show" role="alert">
					Dadus  Suco Susesu Update!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/suco');
		}
	}
		public function delete($id)
	{
		$where = array('id' => $id);
		$this->suco_model->hamos_data($where, 't_suco');
		$this->session->set_flashdata('mensagem','<div class="alert alert-danger alert-dismissible fade show" role="alert">
					Dadus Suco Susesu Hamos!
				  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>');
		redirect('administrator/suco');
	}
	public function print()
	{
		$data['t_suco']= $this->suco_model->fosai_dadus('t_suco')->result();
        $this->load->view('administrator/print_suco',$data);
	}

	public function pdf  (){
        $this->load->library('dompdf_gen');
        $data['t_suco']=$this->suco_model->fosai_dadus("t_suco")->result();
        $this->load->view('administrator/relsuco_pdf',$data);

        $paper_size='A4';
        $orientation='landscape';
        $html=$this->output->get_output();
        $this->dompdf->set_paper($paper_size, $orientation);

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream("lapor_mahasiswa.pdf", array('attachment'=>0));
     }

}