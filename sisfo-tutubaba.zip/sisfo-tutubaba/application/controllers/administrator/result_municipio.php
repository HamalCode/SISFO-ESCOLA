<?php 
class result_municipio extends CI_Controller{
	public function index()
	{
		
		 $data['start'] = $this->uri->segment(4);
		$data['t_municipio']  =$this->municipio_model->fosai_dadus('t_municipio')->result();
		
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/result_municipio',$data);
		$this->load->view('templates_administrator/footer');
	}
	
	
	
	
	
}