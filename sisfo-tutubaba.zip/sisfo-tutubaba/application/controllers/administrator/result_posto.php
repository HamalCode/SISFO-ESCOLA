<?php 
class result_posto extends CI_Controller{
	public function index()
	{
		$data['t_posto'] = $this->posto_model->fosai_dadus('t_posto')->result();
		$data['t_municipio'] = $this->posto_model->fosai_dadus('t_municipio')->result();
		$this->load->view('templates_administrator/header');
		$this->load->view('templates_administrator/sidebar');
		$this->load->view('administrator/result_posto',$data);
		$this->load->view('templates_administrator/footer');

	}

}