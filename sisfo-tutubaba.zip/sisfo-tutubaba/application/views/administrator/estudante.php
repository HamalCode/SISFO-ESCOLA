<div class="container-fluid">
	<div class="alert alert-info bg-info text-white" role="alert">
	    <i class="fas fa-book"></i> <b>DADUS REGISTU ESTUDANTE EBC No<sup>o</sup> 519 FILIAL TUTUBABA</b>
	  </div>
	   <?php echo $this->session->flashdata('mensagem') ?>
	  <?php echo anchor('administrator/estudante/amenta_estudante',' <button class="btn btn-sm btn-primary mb-3"><i class="fas fa-plus fa-sm"></i> Registu Estudante</button>') ?>

	 
	<table class="table table-striped table-hover table-bordered">

		<tr>
			<thead class="thead-dark">
			<th>NO</th>
			<th>NO.REGISTU/NRE</th>
			<th>NARAN ESTUDANTE</th>
			<th>ID E-ANTERIOR</th>
			<th>HELA FATIN</th>
			<th>NO. CONTACTON</th>
			<th colspan="3">ASAUN</th>
			</thead>
		</tr>
		
		  

			<?php foreach($t_estudante as $est) : ?>
				<tr>
					<td><?php echo ++$start ?></td>
					<td><?php echo $est->nre ?></td>
					<td><?php echo $est->nrn_estudante ?></td>
					<td><?php echo $est->code_escante ?></td>
					<td><?php echo $est->hela_fatin ?></td>
					<td><?php echo $est->no_tfn ?></td>
					
					<td width="20px"><?php echo anchor('administrator/estudante/detail/'.$est->id,'<div class="btn btn-sm btn-info"><i class="fa fa-eye"></i></div>')?></td>

					<td width="20px"><?php echo anchor('administrator/estudante/update/'.$est->id,'<div class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></div>')?></td>

	  	 	  <td width="20px"><?php echo anchor('administrator/estudante/delete/'.$est->id,'<div class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></div>')?></td>
				</tr>
			<?php endforeach; ?>
			
	</table>
	
	 <?= $this->pagination->create_links(); ?>
	
</div>