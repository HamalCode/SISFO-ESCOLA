<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<body style="padding: 0 20;">
    <div>
      <section class="content">
        <div class="row">
            <div>
                <div class="span12">
                    <table class=""table table-striped table-hover table-bordered">
                        <tbody>
                            <tr>
                                <!-- <td><h2><strong>No Tagihan </strong>#<?php echo $data['notagihan']; ?> </h2></td> -->
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div><center ><strong>  ENSINO BASICO CENTRAL N<SUP>o</SUP>519 FILIAL TUTUBA
       <br> RELATORIO DADUS REGISTASAUN ESTUDANTE EBC TUTUBABA </strong> <br>
            <i>Ministerio da Educa&ccedil;&atilde;o e Cultura <br>
              
        </center>
          
          <div class="row">
            <div class="col-xs-12 table-responsive" border="1" >
              <table class="table table-striped" align="center">
                <thead class="thead-dark text-center">
                <tr>
                  <th>NO</th>
                  <th>NRE</th>
                  <th>ID ESCANTE</th>
                  <th>NARAN</th>
                  <th>SEXO</th>
                   <!-- <th>ID MUNICIPIO</th>
                  <th>ID POSTO</th>
                   <th>ID SUCO</th> -->
                  <th>INAN</th>
                  <th>AMAN</th>
                  <th>RELIGIAUN</th>
                  <th>HELA FATIN</th>
                  <th> NO.TLF</th>
             
                </tr>
                </thead>
                <tbody>
                    <?php 
          $no=1;
          foreach ($t_estudante as $est) : ?>
            
            <tr>
              <td><?php echo $no++ ?></td>
             <td><?php echo $est->nre ?></td>
             <td><?php echo $est->code_escante ?></td>
              <td><?php echo $est->nrn_estudante ?></td>
              <td><?php echo $est->sexo ?></td>
              <!-- <td><?php echo $est->code ?></td>
              <td><?php echo $est->code_posto ?></td>
              <td><?php echo $est->code_suco ?></td> -->
              <td><?php echo $est->inan ?></td>
              <td><?php echo $est->aman ?></td>
              <td><?php echo $est->reli ?></td>
              <td><?php echo $est->hela_fatin ?></td>
              <td><?php echo $est->no_tfn ?></td>
              
            </tr>
            
          <?php endforeach; ?>
         
                </tbody>
            </table>
          </div>
      </section>
    </div>
  </body>

  
   <script type="text/javascript">
     window.print();
   </script>