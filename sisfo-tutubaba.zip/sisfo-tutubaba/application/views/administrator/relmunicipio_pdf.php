<center><H2>RELATORIO MUNICIPIO</H2></center><br><hr><html>
<head><link rel="stylesheet" type="text/css" href="style.css">
	<title></title>
</head><body>
	<table align="center"cellspacing='0' border="1" width="70%">
	
			<tr>
			<th bgcolor="silver">NO</th>
			<th bgcolor="silver">ID MUNICIPIO</th>
			<th bgcolor="silver">NARAN MUNICIPIO</th>			
			</tr>
		</tr>
			<?php 
		$no=1;
		foreach ($t_municipio as $mun) : ?>
			<tr>
				    <td class="text-center"><?php echo $no++ ?></td>
				   <td class="text-center"><?php echo $mun->code?></td>
	  	 	       <td  class="text-center"><?php echo $mun->nrn_municipio?></td>										
			</tr>
		<?php endforeach; ?>
		
	</table>
</body></html>