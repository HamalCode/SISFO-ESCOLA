<div class="container-fluid">
	<div class="alert alert-success" role="alert">
	    <i class="fas fa-book"></i> FORMULARIO REGISTU ESCOLA ANTERIOR
	  </div>
	 
	  <?php echo form_open_multipart('administrator/escante/asaun_amenta_escante') ?>
	  <div class="form-group">
	  	<label>ID ESCANTE</label>
	  	<input type="text" name="code_escante" class="form-control">
	  	<?php echo form_error('code_escante','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	   <div class="form-group">
	  	<label>ID SUCO</label>
	  	<select name="code_suco" class="form-control">
	  		<option value="">--Hili Id Suco--</option>
	  		<?php foreach($t_suco as $suc) : ?>
	  		<option value="<?php echo $suc->code_suco ?>"><?php echo $suc->code_suco ?></option>
	  	<?php endforeach ?>
	  	</select>
	  	<?php echo form_error('code_suco','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	  <div class="form-group">
	  	<label>NARAN ESCOLA ANTERIOR</label>
	  	<input type="text" name="nrn_escante" class="form-control">
	  	<?php echo form_error('nrn_escante','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	
 	<button type="reset" class="btn btn-danger mb-3" data-dismiss="modal">Reset</button>
 	<button type="submit" class="btn btn-primary mb-3">Rai</button>

	  <?php echo form_close(); ?>
</div>