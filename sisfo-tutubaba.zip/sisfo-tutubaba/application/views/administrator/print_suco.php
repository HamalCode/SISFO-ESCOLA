<div class="container-fluid">
		<div class="alert alert-info bg-info text-white text-center" role="alert">
	 <center><b>RELATORIO REGISTU SUCOS</b></center>  <br>
	  </div>
	  

	  <table align="center" border="1" width="70%">
	  	<tr>
	  		<thead class="thead-dark">
	  		<th class="" bgcolor="silver">NO</th>
	  		<th class="text-center" bgcolor="silver">ID POSTO</th>
	  		<th class="text-center" bgcolor="silver">NARAN POSTO</th>
	  			</thead>
	  	</tr>
	  	<?php 
	  	$no =1;
	  	foreach ($t_suco as $suc):
	  	 ?>
	  	 <tr>
	  	 	<td width="20px"><?php echo $no++ ?></td>
	  	 	<td class="text-center" width="50px"><?php echo $suc->code_suco?></td>
	  	 	<td class="text-center" width="50px"><?php echo $suc->nrn_suco?></td>
	  	 	 </tr>
	  	 	<?php endforeach; ?>
	  </table>
</div>
<script type="text/javascript">
	window.print();
</script>