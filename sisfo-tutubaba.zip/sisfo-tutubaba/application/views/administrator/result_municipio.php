<div class="container-fluid">
	<div class="alert alert-info bg-info text-white text-center" role="alert">
	  <b>RELATORIO REGISTU MUNICIPIO</b>
</div>
	     
<?php echo anchor('administrator/municipio/print',' <button class="btn btn-sm btn-secondary mb-3"><i class="fa fa-print"></i> Print Data</button>') ?>
<?php echo anchor('administrator/municipio/pdf',' <button class="btn btn-sm btn-secondary mb-3"><i class="fa fa-file-pdf"></i> Export PDF</button>') ?>
	  <table class="table table-bordered table-striped table-hover">
	  	<tr>
	  		<thead class="thead-dark">
	  		<th>NO</th>
	  		<th  class="text-center">ID MUNICIPIO</th>
	  		<th  class="text-center">NARAN MUNICIPIO</th>
	  	   </thead>
	  	</tr>
	  	<?php 
	  	$no =1;
	  	foreach ($t_municipio as $mun):
	  	 ?>
	  	 <tr>
	  	 	<td width="20px"><?php echo $no++ ?></td>
	  	 	<td class="text-center"><?php echo $mun->code?></td>
	  	 	<td  class="text-center"><?php echo $mun->nrn_municipio?></td>
	  	 	
	  	 </tr>
	  	 	<?php endforeach; ?>
	  </table>
	  <!-- <?= $this->pagination->create_links(); ?> -->
	  
</div>