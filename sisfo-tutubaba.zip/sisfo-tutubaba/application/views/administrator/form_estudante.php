<div class="container-fluid">
	<div class="alert alert-dark" role="alert">
	    <i class="fas fa-book"></i> FORMULARIO REGISTU ESTUDANTE FOUN
	  </div>
	  <?php echo form_open_multipart('administrator/estudante/asaun_amenta_estudante') ?>
	  <div class="form-group">
	  	<label>No.REGISTU/NRE</label>
	  	<input type="text" name="nre" class="form-control">
	  	<?php echo form_error('nre','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	  <div class="form-group">
	  	<label> ID ESCOLA ANTERIOR</label>
	  	<select name="code_escante" class="form-control">
	  		<option value="">--HILI--</option>
	  		<?php foreach($t_esc_ante as $esc) : ?>
	  		<option value="<?php echo $esc->code_escante ?>"><?php echo $esc->code_escante ?></option>
	  	<?php endforeach ?>
	  	</select>
	  	<?php echo form_error('code_escante','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

     <div class="form-group">
	  	<label>NARAN ESTUDANTE</label>
	  	<input type="text" name="nrn_estudante" class="form-control">
	  	<?php echo form_error('nrn_estudante','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	  <div class="form-group">
	  	<label>SEXO</label>
	  	<select name="sexo" class="form-control">
	  		<option value="">--HILI SEXO--</option>
	  		<option>Mane</option>
	  		<option>Feto</option>
	  	</select>
	  	<?php echo form_error('sexo','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	  <div class="form-group">
	  	<label>ID MUNICIPIO</label>
	  	<select name="code" class="form-control">
	  		<option value="">--Hili ID Municipio--</option>
	  		<?php foreach($t_municipio as $mun) : ?>
	  		<option value="<?php echo $mun->code ?>"><?php echo $mun->code ?></option>
	  	<?php endforeach ?>
	  	</select>
	  	<?php echo form_error('code','<div class="text-danger small ml-3">','</div>') ?>
	  </div>
      
	
	  <div class="form-group">
	  	<label>ID POSTO</label>
	  	<select name="code_posto" class="form-control">
	  		<option value="">--Hili  Posto--</option>
	  		<?php foreach($t_posto as $pos) : ?>
	  		<option value="<?php echo $pos->code_posto ?>"><?php echo $pos->code_posto ?></option>
	  	<?php endforeach ?>
	  	</select>
	  	<?php echo form_error('code_posto','<div class="text-danger small ml-3">','</div>') ?>
	  </div>
	  <div class="form-group">
	  	<label>ID SUCO</label>
	  	<select name="code_suco" class="form-control">
	  		<option value="">--Hili Suco--</option>
	  		<?php foreach($t_suco as $suc) : ?>
	  		<option value="<?php echo $suc->code_suco ?>"><?php echo $suc->code_suco ?></option>
	  	<?php endforeach ?>
	  	</select>
	  	<?php echo form_error('code_suco','<div class="text-danger small ml-3">','</div>') ?>
	  </div>
	  <div class="form-group">
	  	<label>INAN</label>
	  	<input type="text" name="inan" class="form-control">
	  	<?php echo form_error('inan','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	  <div class="form-group">
	  	<label>AMAN</label>
	  	<input type="text" name="aman" class="form-control">
	  	<?php echo form_error('aman','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	  <div class="form-group">
	  	<label>RELIJIAUN</label>
	  	<select name="reli" class="form-control">
	  		<option value="">--Hili Religiaun--</option>
	  		<option>Katolika</option>
	  		<option>Islam</option>
	  		<option>Protestante</option>
	  		<option>Hindu</option>
	  		<option>Budah</option>
	  	</select>
	  	<?php echo form_error('reli','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	  <div class="form-group">
	  	<label>HELA FATIN ATUAL</label>
	  	<input type="text" name="hela_fatin" class="form-control">
	  	<?php echo form_error('hela_fatin','<div class="text-danger small ml-3">','</div>') ?>
	  </div>


	  <div class="form-group">
	  	<label>No. CONTACTO</label>
	  	<input type="text" name="no_tfn" class="form-control">
	  	<?php echo form_error('no_tfn','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	   <div class="form-group">
	  	<label>OBSERVASAUN</label>
	  	<input type="text" name="obs" class="form-control">
	  	<?php echo form_error('obs','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	  <div class="form-group">
	  	<label>FOTO</label><br>
	  	<input type="file" name="foto">
	  </div>
 	<button type="reset" class="btn btn-danger mb-3" data-dismiss="modal">Reset</button>
 	<button type="submit" class="btn btn-primary mb-3">Rai</button>



	  <?php echo form_close(); ?>
</div>