<div class="container-fluid">
	<div class="alert alert-info bg-info text-white" role="alert">
	    <i class="fas fa-university"></i>  <b>DADUS REGISTU MUNICIPIO</b>
</div>
	     <?php echo $this->session->flashdata('mensagem') ?>
	  <?php echo anchor('administrator/municipio/input',' <button class="btn btn-sm btn-warning mb-3"><i class="fas fa-plus fa-sm"></i> Registu Municipio</button>') ?>


	  <table class="table table-bordered table-striped table-hover">
	  	<tr>
	  		<thead class="thead-dark">
	  		<th>NO</th>
	  		<th>ID MUNICIPIO</th>
	  		<th>NARAN MUNICIPIO</th>
	  		<th colspan="2">ASAUN</th>
	  		</thead>
	  	</tr>
	  	<?php 
	  	$no =1;
	  	foreach ($t_municipio as $mun):
	  	 ?>
	  	 <tr>
	  	 	<td width="20px"><?php echo $no++ ?></td>
	  	 	<td><?php echo $mun->code?></td>
	  	 	<td><?php echo $mun->nrn_municipio?></td>
	  	 	<td width="20px"><?php echo anchor('administrator/municipio/update/'.$mun->id_municipio,'<div class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></div>')?></td>

	  	 	<td width="20px"><?php echo anchor('administrator/municipio/delete/'.$mun->id_municipio,'<div class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></div>')?></td>
	  	 </tr>
	  	 	<?php endforeach; ?>
	  </table>
	  <!-- <?= $this->pagination->create_links(); ?> -->
	  
</div>