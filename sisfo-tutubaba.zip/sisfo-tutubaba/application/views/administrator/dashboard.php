<div class="container-fluid">
    <div class="alert alert-dark bg-danger text-white" role="alert">
    <i class="fas fa-tachometer-alt"></i> Favor Klik iha Menu Sorin karuk no Control Panel hodi maneza ita nia Sistema!
  </div>
      <div class="alert alert-info" role="alert">
      <h4 class="alert-heading">Bemvido!</h4>
      <p>Bemvindo mai <strong><?php echo $username; ?></strong> Sistema Informasaun Registu Estudante Foun iha EBC Tutubaba. ita boot Login hanesan <strong><?php echo $level; ?></strong>.</p>
     
      <hr>
      <button type="button" class="btn btn-sm btn-dark" data-toggle="modal" data-target="#exampleModal">
      <i class="fas fa-cogs"></i> <b>Control Panel</b>
      </button>
    </div>
              <!-- Button trigger modal -->
          

          <!-- Modal -->
          <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
              <div class="modal-content">
                <div class="modal-header btn-warning">
                  <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-cogs"></i>Control Panel</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                 <div class="row">
                   <div class="col-md-3 text-info text-center">
                     <a href="<?php echo base_url('administrator/result_municipio') ?>"  ><p class="nav-link small text-info">Dadus Municipio</p></a>
                     <i class="fas fa-3x fa-database"></i>
                   </div>

                   <div class="col-md-3 text-info text-center">
                     <a href="<?php echo base_url('administrator/result_posto') ?>"  ><p class="nav-link small text-info">Dadus Posto</p></a>
                     <i class="fas fa-3x fa-book"></i>
                   </div>
                   <div class="col-md-3 text-info text-center">
                     <a href="<?php echo base_url('administrator/result_suco') ?>"><p class="nav-link small text-info">Dadus Suco</p></a>
                     <i class="fas fa-3x fa-edit"></i>
                   </div>
                   <div class="col-md-3 text-info text-center">
                     <a href="<?php echo base_url('administrator/result_escante') ?>"  ><p class="nav-link small text-info">Dadus Escola Anterior </p></a>
                     <i class="fas fa-3x fa-home"></i>
                   </div> <hr>
                 
                   <div class="col-md-3 text-info text-center">
                     <a href="<?php echo base_url('administrator/result_estudante') ?>"  ><p class="nav-link small text-info">Dadus Estudante</p></a>
                     <i class="fas fa-3x fa-user-graduate"></i>
                   </div>

                   <div class="col-md-3 text-info text-center">
                     <a href="<?php echo base_url('administrator/prosesu') ?>"  ><p class="nav-link small text-info">Prosesu Estudante</p></a>
                     <i class="fa fa-3x fa-file-pdf"></i>
                   </div>

                  

                 </div>
                </div>
                <div class="modal-footer bg-dark">
                  <button type="button" class="btn btn-danger" data-dismiss="modal">Taka</button>
                  
                </div>
              </div>
            </div>
          </div>
</div>