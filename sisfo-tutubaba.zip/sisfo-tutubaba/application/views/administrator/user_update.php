<div class="container-fluid">
	<div class="alert alert-success" role="alert">
      <i class="fas fa-users"></i> FORM UPDATE USER
    </div>
    <?php foreach($user as $user) :?>
    <form method="post" action="<?php echo base_url('administrator/user/asaun_update') ?>">
   
    <div class="form-group">
      <label>USERNAME</label>
      <input type="hidden" name="id" placeholder="hatama id" class="form-control" value="<?php echo $user->id ?>">
    
      <input type="text" name="username" placeholder="hatama Username" class="form-control"value="<?php echo $user->username ?>">
      <?php echo form_error('username','<div class="text-danger small" ml-3>') ?>
    </div>
    <div class="form-group">
      <label>PASSWORD</label>
      <input type="password" name="password" placeholder="hatama password " class="form-control" value="<?php echo $user->password ?>">
      <?php echo form_error('password','<div class="text-danger small" ml-3>') ?>
    </div>
    <div class="form-group">
      <label>EMAIL</label>
      <input type="text" name="email" placeholder=" Hatama Email " class="form-control" value="<?php echo $user->email ?>">
      <?php echo form_error('email','<div class="text-danger small" ml-3>') ?>
    </div>
    <div class="form-group">
      <label>LEVEL</label>
     <select name="level" class="form-control">
     	<?php if($level =='admin'){
     	 ?>
     	 <option value="admin" selected>Admin</option>
     	 <option value="staf">Staff</option>
     	 <?php 
     	 	}elseif($level == 'staf'){
     	  ?>
     	  <option value="admin" selected>Admin</option>
     	 <option value="staf" selected>Staff</option>

     	<?php 

     		}else{

     	 ?>
     	 <option value="admin">Admin</option>
     	 <option value="staf">Staff</option>
     	<?php } ?>
     </select>

      <?php echo form_error('level','<div class="text-danger small" ml-3>') ?>
    </div>

    <div class="form-group">
      <label>Blokir</label>
     <select name="blokir" class="form-control">
     	<?php if($blokir =='Y'){
     	 ?>
     	 <option value="Y" selected>Sim</option>
     	 <option value="N">Lae</option>
     	 <?php 
     	 	}elseif($blokir == 'N'){
     	  ?>
     	  <option value="Y">Sim</option>
     	 <option value="N" selected>Lae</option>

     	<?php 

     		}else{

     	 ?>
     	 <option value="Y">Sim</option>
     	 <option value="N" selected>Lae</option>
     	<?php } ?>
     </select>

      <?php echo form_error('blokir','<div class="text-danger small" ml-3>') ?>
    </div>

    <button type="submit" class="btn btn-primary">Rai</button>
  
  </form>
<?php endforeach ?>
</div>