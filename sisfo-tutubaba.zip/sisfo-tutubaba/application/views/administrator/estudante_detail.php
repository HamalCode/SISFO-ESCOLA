<div class="container-fluid col-md-8">
	<div class="alert alert-dark container-fluid col-md-12" role="alert">
	    <i class="fas fa-book"></i> LISTA DETALHO REGISTU ESTUDANTE FOUN
		
	  </div>
	  <?php echo anchor('administrator/estudante','<div class="btn btn-sm btn-primary">Fila</div>') ?> <br> <br>
	  <table class="table table-hover table-bordered table-striped">

	  	<?php foreach($detail as $dt) ?>
	  	
	  	
	  	<tr>
	  		<td>No. REGISTO/NRE</td>
	  		<td><?php echo $dt->nre; ?></td>
	  	</tr>

	  	<tr>
	  		<td>ID ESCOLA ANTERIOR</td>
	  		<td><?php echo $dt->code_escante; ?></td>
	  	</tr>

	  	<tr>
	  		<td>Naran Estudante</td>
	  		<td><?php echo $dt->nrn_estudante; ?></td>
	  	</tr>
	  	<tr>
	  		<td>SEXO</td>
	  		<td><?php echo $dt->sexo; ?></td>
	  	</tr>

	  	<tr>
	  		<td>ID Municipio</td>
	  		<td><?php echo $dt->code; ?></td>
	  	</tr>
	  	<tr>
	  		<td> ID POSTO</td>
	  		<td><?php echo $dt->code_posto; ?></td>
	  	</tr>
	  	<tr>
	  		<td> SUCO</td>
	  		<td><?php echo $dt->code_suco; ?></td>
	  	</tr>

	  		<tr>
	  		<td>Inan</td>
	  		<td><?php echo $dt->inan; ?></td>
	  	</tr>

	  	<tr>
	  		<td>Aman</td>
	  		<td><?php echo $dt->aman; ?></td>
	  	</tr>

	  	<tr>
	  		<td>Religiaun</td>
	  		<td><?php echo $dt->reli; ?></td>
	  	</tr>

	  	<tr>
	  		<td>Hela Fatin</td>
	  		<td><?php echo $dt->hela_fatin; ?></td>
	  	</tr>


	  	<tr>
	  		<td>No. Tfn </td>
	  		<td><?php echo $dt->no_tfn; ?></td>
	  	</tr>

	  	<tr>
	  		<td>Observasaun</td>
	  		<td><?php echo $dt->obs; ?></td>
	  	</tr>
	  	
		  

	  </table>
	  
	  <img class="mb-5" src="<?php echo base_url('assets/uploads/').$dt->foto ?>" style="width:10%">
	 
</div>