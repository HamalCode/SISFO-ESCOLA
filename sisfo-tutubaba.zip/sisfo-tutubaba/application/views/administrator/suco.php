
<div class="container-fluid">
		<div class="alert alert-info bg-info text-white" role="alert">
	    <i class="fas fa-university"></i> <b>DADUS SUCOS</b>
	  </div>
	  <?php echo $this->session->flashdata('mensagem') ?>
	  <?php echo anchor('administrator/suco/amenta_suco',' <button class="btn btn-sm btn-warning mb-3"><i class="fas fa-plus fa-sm"></i> Amenta Suco</button>') ?>
	 

	  <table class="table table-bordered table-striped table-hover">
	  	<tr>
	  		<thead class="thead-dark">
	  		<th>NO</th>
	  		<th>ID SUCO</th>
	  		<th>ID POSTO</th>
	  		<th>NARAN SUCO</th>
	  		<th colspan="2">ASAUN</th>
	  		</thead>
	  	</tr>
	  	<?php 
	  	$no =1;
	  	foreach ($t_suco as $suc):
	  	 ?>
	  	 <tr>
	  	 	<td width="20px"><?php echo $no++ ?></td>
	  	 	<td><?php echo $suc->code_suco?></td>
	  	 	<td><?php echo $suc->code_posto?></td>
	  	 	<td><?php echo $suc->nrn_suco?></td>
	  	 	<td width="20px"><?php echo anchor('administrator/suco/update/'.$suc->id,'<div class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></div>')?></td>

	  	 	<td width="20px"><?php echo anchor('administrator/suco/delete/'.$suc->id,'<div class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></div>')?></td>
	  	 </tr>
	  	 	<?php endforeach; ?>
	  </table>
</div>