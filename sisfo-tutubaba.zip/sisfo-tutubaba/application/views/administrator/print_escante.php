<div class="container-fluid">
		<div class="alert alert-info bg-info text-white text-center" role="alert">
	 <center><b>RELATORIO ESCOLA ANTERIORIOR</b></center>  <br>
	  </div>
	  

	  <table align="center" border="1" width="70%">
	  	<tr>
	  		<thead class="thead-dark">
	  		<th class="" bgcolor="silver">NO</th>
	  		<th class="text-center" bgcolor="silver">ID ESCOLA ANTERIOR</th>
	  		<th class="text-center" bgcolor="silver">NARAN ESCOLA ANTERIOR</th>
	  			</thead>
	  	</tr>
	  	<?php 
	  	$no =1;
	  	foreach ($t_esc_ante as $esc):
	  	 ?>
	  	 <tr>
	  	 	<td width="20px"><?php echo $no++ ?></td>
	  	 	<td class="text-center" width="50px"><?php echo $esc->code_escante?></td>
	  	 	<td class="text-center" width="50px"><?php echo $esc->nrn_escante?></td>
	  	 	 </tr>
	  	 	<?php endforeach; ?>
	  </table>
</div>
<script type="text/javascript">
	window.print();
</script>