<center><H2>RELATORIO POSTO ADMINISTRATIVU</H2></center><br><hr><html>
<head><link rel="stylesheet" type="text/css" href="style.css">
	<title></title>
</head><body>
	<table align="center"cellspacing='0' border="1" width="70%">
	
			<tr>
			<th>NO</th>
			<th>ID POSTO</th>
			<th>ID MUNICIPIO</th>
			<th>NARAN POSTO</th>			
			</tr>
		</tr>
			<?php 
		$no=1;
		foreach ($t_posto as $pos) : ?>
			<tr>
				    <td><?php echo $no++ ?></td>
					<td><?php echo $pos->code_posto ?></td>
				    <td><?php echo $pos->code ?></td>
				     <td><?php echo $pos->nrn_posto ?></td>										
			</tr>
		<?php endforeach; ?>
		
	</table>
</body></html>