<div class="container-fluid">
	<div class="alert alert-danger bg-danger text-white">
		<i class="fas fa-users"></i> REGISTA USERS
	</div>
	<?php echo $this->session->flashdata('mensagem') ?>

	<?php echo anchor('administrator/user/amenta_user','<button class="btn btn-sm btn-primary mb-3"><i class="fas fa-plush fa-sm"></i>Regista Users</button>') ?>
 
	<table class="table table-bordered table-striped table-hover">
		<thead class="thead-dark">
			<tr>
				<th>NO</th>
				<th>USERNAME</th>
				<th>EMAIL</th>
				<th>LEVEL</th>
				<th>BLOKEIA</th>
				<th colspan="2"></th>

			</tr>
		</thead>

		<?php 
		$no=1;
			foreach ($user as $user): ?>
				<tr>
				<td><?php echo $no++ ?></td>
				<td><?php echo $user->username ?></td>
				<td><?php echo $user->email ?></td>
				<td><?php echo $user->level ?></td>
				<td><?php echo $user->blokir ?></td>
				<td width="20px"><?php echo anchor('administrator/user/update/'.$user->id,'<div class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></div>')?></td>

	  	 	<td width="20px"><?php echo anchor('administrator/user/delete/'.$user->id,'<div class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></div>')?></td>
	  	 </tr>
			<?php endforeach; ?>
	</table>

</div>