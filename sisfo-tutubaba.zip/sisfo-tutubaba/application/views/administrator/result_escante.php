<div class="container-fluid">
		<div class="alert alert-info bg-info text-white text-center" role="alert">
	     <b>RELATORIO REGISTU DADUS ESCOLA ANTERIOR</b>
	  </div>
	 
	 
<?php echo anchor('administrator/escante/print',' <button class="btn btn-sm btn-danger mb-3"><i class="fa fa-print"></i> Print</button>') ?>

		<?php echo anchor('administrator/escante/pdf',' <button class="btn btn-sm btn-warning mb-3"><i class="fa fa-file-pdf"></i> Export PDF</button>') ?>

	  <table class="table table-bordered table-striped table-hover">
	  	<tr>
	  		<thead class="thead-dark">
	  		<th>NO</th>
	  		<th class="text-center">ID ESCOLA ANTERIOR</th>	  		
	  		<th class="text-center">NARAN ESCOLA ANTERIOR</th>	  		
	  		</thead>
	  	</tr>
	  	<?php 
	  	$no =1;
	  	foreach ($t_esc_ante as $esc):
	  	 ?>
	  	 <tr>
	  	 	<td width="20px"><?php echo $no++ ?></td>
	  	 	<td class="text-center"><?php echo $esc->code_escante?></td>
	  	 	<td class="text-center"><?php echo $esc->nrn_escante?></td>
	  	 	
	  	 </tr>
	  	 	<?php endforeach; ?>
	  </table>
</div>