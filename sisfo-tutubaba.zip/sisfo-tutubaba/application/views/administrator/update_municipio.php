<div class="container-fluid">
	<div class="alert alert-success" role="alert">
	    <i class="fas fa-university"></i> Form Update Municipio
	  </div>
	  <?php foreach ($t_municipio as $mun) :?>

	  	<form method="post" action="<?php echo base_url('administrator/municipio/asaun_update') ?>">
	  		<div class="form-group">
	  			<label>ID Municipio</label>
	  			<input type="hidden" name="id_municipio" value="<?php echo $mun->id_municipio ?>">
	  			<input type="text" name="code" class="form-control" value="<?php echo $mun->code ?>">
	  		</div>

	  		<div class="form-group">
	  			<label>Naran Municipio</label>
	  			<input type="text" name="nrn_municipio" class="form-control" value="<?php echo $mun->nrn_municipio ?>">
	  		</div>

	  		<button type="submit" class="btn btn-primary">Rai</button>

	  	</form>

	  <?php endforeach; ?>
</div>