<div class="container-fluid">
	<div class="alert alert-success" role="alert">
	    <i class="fas fa-book"></i> FORMULARIO UPDATE POSTO
	  </div>
	  <?php foreach($t_suco as $suc) :?>
	  <?php echo form_open_multipart('administrator/suco/asaun_update_suco') ?>
	  <div class="form-group">
	  	<label>ID SUCO</label>
		  <input type="hidden" name="code_suco" class="form-control" value="<?php echo $suc->code_suco ?>">
	  	<input type="text" name="code_suco" class="form-control" value="<?php echo $suc->code_suco ?>">
	  	<?php echo form_error('code_suco','<div class="text-danger small ml-3">','</div>') ?>
	  </div>


	  <div class="form-group">
	  	<label>POSTO</label>
	  	<select name="code_posto" class="form-control" value="<?php echo $pos->code_posto ?>">
	  		<?php foreach($t_posto as $pos) : ?>
	  		<option value="<?php echo $pos->code_posto ?>"><?php echo $pos->code_posto ?></option>
	  	<?php endforeach ?>
	  	</select>
	  	<?php echo form_error('code_posto','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	  <div class="form-group">
	  	<label>NARAN SUCO</label>
	  	<input type="text" name="nrn_suco" class="form-control" value="<?php echo $suc->nrn_suco ?>">
	  	<?php echo form_error('nrn_suco','<div class="text-danger small ml-3">','</div>') ?>
	  </div>



	
 	<button type="reset" class="btn btn-danger mb-3" data-dismiss="modal">Reset</button>
 	<button type="submit" class="btn btn-primary mb-3">Rai</button>

	  <?php echo form_close(); ?>
	<?php endforeach; ?>
</div>