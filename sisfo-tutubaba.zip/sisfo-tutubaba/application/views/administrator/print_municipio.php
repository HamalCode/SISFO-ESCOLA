



<div class="container-fluid">
	<div class="alert alert-info bg-info text-white text-center" role="alert">
	  <b>RELATORIO REGISTU MUNICIPIO</b> <br>	
</div>
	     


	  <table border="1" class="center">
	  	<tr>
	  		<thead class="thead-dark">
	  		<th>NO</th>
	  		<th  class="text-center">ID MUNICIPIO</th>
	  		<th  class="text-center">NARAN MUNICIPIO</th>
	  	   </thead>
	  	</tr>
	  	<?php 
	  	$no =1;
	  	foreach ($t_municipio as $mun):
	  	 ?>
	  	 <tr>
	  	 	<td width="20px"><?php echo $no++ ?></td>
	  	 	<td class="text-center"><?php echo $mun->code?></td>
	  	 	<td  class="text-center"><?php echo $mun->nrn_municipio?></td>
	  	 	
	  	 </tr>
	  	 	<?php endforeach; ?>
	  </table>
	
	  
</div>
<script type="text/javascript">
     window.print();
   </script>