<center><strong>  ENSINO BASICO CENTRAL N<SUP>o</SUP>519 FILIAL TUTUBA
       <br> RELATORIO DADUS REGISTASAUN ESTUDANTE EBC TUTUBABA </strong> <br>
            <i>Ministerio da Educa&ccedil;&atilde;o e Cultura <br>
              </center><br><hr><html>
<head><link rel="stylesheet" type="text/css" href="style.css">
	<title></title>
</head><body>
	<table cellspacing='0' border="0" align="center">
	
			<tr>
			<th>NO</th>
			<th>NRE</th>
			<th>ID ESC-ANTE</th>
			<th>NARAN</th>
			<th>SEXO</th>
			<!-- <th>ID MUNICIPIO</th>
			<th>ID POSTU</th>
			<th>ID SUCO</th> -->
			<th>INAN</th>
			<th>AMAN</th>
			<th>RELIGIAUN</th>
			<th>HELA FATIN</th>
			<th> NO.TLF</th>
			<!-- <th>OBSERVASAUN</th> -->
			</tr>
		
			</tr>
		<?php 
		$no=1;
		foreach ($t_estudante as $est) : ?>
			<tr>
				    <td><?php echo $no++ ?></td>
				    <td><?php echo $est->nre ?></td>
				     <td><?php echo $est->code_escante ?></td>
					<td><?php echo $est->nrn_estudante ?></td>
					<td><?php echo $est->sexo ?></td>
					<!-- <td><?php echo $est->code ?></td>
					<td><?php echo $est->code_posto ?></td>
					<td><?php echo $est->code_suco ?></td> -->
					<td><?php echo $est->inan ?></td>
					<td><?php echo $est->aman ?></td>
					<td><?php echo $est->reli ?></td>
					<td><?php echo $est->hela_fatin ?></td>
					<td><?php echo $est->no_tfn ?></td>
					<!-- <td><?php echo $est->obs ?></td> -->
					
			</tr>
		<?php endforeach; ?>
		
	</table>
</body></html>