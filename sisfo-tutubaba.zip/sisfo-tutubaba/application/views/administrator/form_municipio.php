<div class="container-fluid">
	<div class="alert alert-success" role="alert">
	    <i class="fas fa-university"></i>FORM REGISTU MUNICIPIO
	  </div>
	<form method="post" action="<?php echo base_url('administrator/municipio/asaun_input') ?>">
		<div class="form-group">
			<label>ID MUNICIPIO</label>
			<input type="text" name="code" placeholder="Id municipio" class="form-control">
			<?php echo form_error('code','<div class="text-danger small" ml-3>') ?>

		</div>

		<div class="form-group">
			<label>MUNICIPIO</label>
			<input type="text" name="nrn_municipio" placeholder="naran municipio" class="form-control">
			<?php echo form_error('nrn_municipio','<div class="text-danger small" ml-3>') ?>
		</div>

		<button type="submit" class="btn btn-primary">Rai</button>
	</form>
</div>