<div class="container-fluid">
	<div class="alert alert-success" role="alert">
	    <i class="fas fa-book"></i> FORMULARIO REGISTO POSTO ADMINISTRATIVU
	  </div>
	 
	  <?php echo form_open_multipart('administrator/posto/asaun_amenta_posto') ?>
	  <div class="form-group">
	  	<label>ID POSTO</label>
	  	<input type="text" name="code_posto" class="form-control">
	  	<?php echo form_error('code_posto','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	   <div class="form-group">
	  	<label>ID MUNICIPIO</label>
	  	<select name="code" class="form-control">
	  		<option value="">--Hili Id Mun--</option>
	  		<?php foreach($t_municipio as $mun) : ?>
	  		<option value="<?php echo $mun->code ?>"><?php echo $mun->code ?></option>
	  	<?php endforeach ?>
	  	</select>
	  	<?php echo form_error('code','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	  <div class="form-group">
	  	<label>Naran Posto</label>
	  	<input type="text" name="nrn_posto" class="form-control">
	  	<?php echo form_error('nrn_posto','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

 	<button type="reset" class="btn btn-danger mb-3" data-dismiss="modal">Reset</button>
 	<button type="submit" class="btn btn-primary mb-3">Rai</button>

	  <?php echo form_close(); ?>
</div>