<div class="container-fluid">
	<div class="alert alert-info bg-secondary text-white" role="alert">
	    <i class="fas fa-book"></i> <b>RELATORIO REGISTU ESTUDANTE EBC N<sup>o</sup>519 FILIAL TUTUBABA</b>
	  </div>
	   <?php echo anchor('administrator/estudante/print',' <button class="btn btn-sm btn-danger mb-3"><i class="fa fa-print"></i> Print</button>') ?>

		<?php echo anchor('administrator/estudante/pdf',' <button class="btn btn-sm btn-secondary mb-3"><i class="fa fa-file-pdf"></i> Export PDF</button>') ?>

	<table class="table table-striped table-hover table-bordered">

		<tr>
			<thead class="bg-secondary text-white">
			<th>NO</th>
			<th>NRE</th>
			<th>NARAN ESTUDANTE</th>
			<th>ID ESC-ANTERIOR</th>
			<th>HELA FATIN</th>
			<th>NO.TFN</th>
			<th colspan="1">Detail</th>
			</thead>
		</tr>
		
		  

			<?php foreach($t_estudante as $est) : ?>
				<tr>
					<td><?php echo ++$start ?></td>
					<td><?php echo $est->nre ?></td>
					<td><?php echo $est->nrn_estudante ?></td>
					<td><?php echo $est->code_escante?></td>
					<td><?php echo $est->hela_fatin ?></td>
					<td><?php echo $est->no_tfn ?></td>
					
					<td width="20px"><?php echo anchor('administrator/estudante/detail/'.$est->id,'<div class="btn btn-sm btn-warning"><i class="fa fa-file-word"></i></div>')?></td>

					
				</tr>
			<?php endforeach; ?>
			
	</table>
	 <?= $this->pagination->create_links(); ?>
	
</div>