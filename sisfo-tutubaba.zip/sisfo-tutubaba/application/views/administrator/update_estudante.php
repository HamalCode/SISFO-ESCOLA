<div class="container-fluid">
	<div class="alert alert-success" role="alert">
	    <i class="fas fa-book"></i> FORMULARIO UPDATE ESTUDANTE
	  </div>

	  <?php foreach($t_estudante as $est) : ?>
	  <?php echo form_open_multipart('administrator/estudante/asaun_update_estudante') ?>
	  <div class="form-group">
	  	<label>NRE</label>
	  	<input type="hidden" name="id" class="form-control" value="<?php echo $est->id ?>">
		  <input type="text" name="nre" class="form-control" value="<?php echo $est->nre ?>">
	  	<?php echo form_error('nre','<div class="text-danger small ml-3">','</div>') ?>
	  </div>


	    <div class="form-group">
	  	<label>ID Escola Anterior</label>
	  	<input type="text" name="code_escante" class="form-control" value="<?php echo $est->code_escante ?>">
	  	<?php echo form_error('code_escante','<div class="text-danger small ml-3">','</div>') ?>
	  </div>


<div class="form-group">
	  	<label>Naran Estudante</label>
	  	<input type="text" name="nrn_estudante" class="form-control" value="<?php echo $est->nrn_estudante ?>">
	  	<?php echo form_error('nrn_estudante','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	  <div class="form-group">
	  	<label>Municipio</label>
	  	<input type="text" name="code" class="form-control" value="<?php echo $est->code ?>">
	  	<?php echo form_error('code','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	   <div class="form-group">
	  	<label>Posto</label>
	  	<input type="text" name="code_posto" class="form-control" value="<?php echo $est->code_posto ?>">
	  	<?php echo form_error('code_posto','<div class="text-danger small ml-3">','</div>') ?>
	  </div>
	  	 <div class="form-group">
	  	<label>Suco</label>
	  	<input type="text" name="code_suco" class="form-control" value="<?php echo $est->code_suco ?>">
	  	<?php echo form_error('code_suco','<div class="text-danger small ml-3">','</div>') ?>
	  </div>


	  <div class="form-group">
	  	<label>Sexo</label>
	  	<select name="sexo" class="form-control" value="<?php echo $est->sexo ?>">
	  		<option>Mane</option>
	  		<option>Feto</option>
	  		<option>Other</option>
	  	</select>
	  	<?php echo form_error('sexo','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	  <div class="form-group">
	  	<label>Naran Inan</label>
	  	<input type="text" name="inan" class="form-control" value="<?php echo $est->inan ?>">
	  	<?php echo form_error('inan','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	  <div class="form-group">
	  	<label>Naran Aman</label>
	  	<input type="text" name="aman" class="form-control" value="<?php echo $est->aman ?>">
	  	<?php echo form_error('aman','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	   <div class="form-group">
	  	<label>Religiaun</label>
	  	<input type="text" name="reli" class="form-control"value="<?php echo $est->reli ?>">
	  	<?php echo form_error('reli','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	  <div class="form-group">
	  	<label>Hela Fatin</label>
	  	<input type="text" name="hela_fatin" class="form-control"value="<?php echo $est->hela_fatin ?>">
	  	<?php echo form_error('hela_fatin','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	  <div class="form-group">
	  	<label>No. Telefone</label>
	  	<input type="text" name="no_tfn" class="form-control"value="<?php echo $est->no_tfn ?>">
	  	<?php echo form_error('no_tfn','<div class="text-danger small ml-3">','</div>') ?>
	  </div>

	 

    <div class="form-group">
	  	<label>Observasaun</label>
	  	<input type="text" name="obs" class="form-control"value="<?php echo $est->obs ?>">
	  	<?php echo form_error('obs','<div class="text-danger small ml-3">','</div>') ?>
	  </div>


	   <div class="form-group">
	  	<?php foreach ($detail as $dt) : ?>
	  		<img src="<?php echo base_url().'assets/uploads/'.$est->foto ?>" width="10%">
	  	<?php endforeach; ?><br><br>
	  	<label>Foto</label><br>
	  	<input type="file" name="userfile" value="<?php echo $est->foto ?>">
	  </div>
 	<button type="reset" class="btn btn-danger mb-3" data-dismiss="modal">Reset</button>
 	<button type="submit" class="btn btn-primary mb-3">Rai</button>

	  <?php echo form_close(); ?>
	<?php endforeach; ?>
</div>