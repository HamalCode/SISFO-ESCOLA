
<div class="container-fluid">
		<div class="alert alert-info bg-info text-white text-center" role="alert">
	    <b>RELATORIO REGISTU SUCOS</b>
	  </div>
	 <?php echo anchor('administrator/suco/print',' <button class="btn btn-sm btn-danger mb-3"><i class="fa fa-print"></i> Print</button>') ?>

		<?php echo anchor('administrator/suco/pdf',' <button class="btn btn-sm btn-warning mb-3"><i class="fa fa-file-pdf"></i> Export PDF</button>') ?>
	 
	  <table class="table table-bordered table-striped table-hover">
	  	<tr>
	  		<thead class="thead-dark">
	  		<th>NO</th>
	  		<th class="text-center">ID SUCO</th>	  		
	  		<th class="text-center">NARAN SUCO</th>
	  		
	  		</thead>
	  	</tr>
	  	<?php 
	  	$no =1;
	  	foreach ($t_suco as $suc):
	  	 ?>
	  	 <tr>
	  	 	<td width="20px"><?php echo $no++ ?></td>
	  	 	<td class="text-center"><?php echo $suc->code_suco?></td>	  	 	
	  	 	<td class="text-center"><?php echo $suc->nrn_suco?></td>
	  	 	
	  	 </tr>
	  	 	<?php endforeach; ?>
	  </table>
</div>