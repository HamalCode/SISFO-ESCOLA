<div class="container-fluid">
		<div class="alert alert-info bg-info text-white" role="alert">
	    <i class="fas fa-university"></i> <b>POSTO ADMINISTRATIVU</b>
	  </div>
	  <?php echo $this->session->flashdata('mensagem') ?>
	  <?php echo anchor('administrator/posto/amenta_posto',' <button class="btn btn-sm btn-warning mb-3"><i class="fas fa-plus fa-sm"></i> Registu Posto </button>') ?>
	 

	  <table class="table table-bordered table-striped table-hover">
	  	<tr>
	  		<thead class="thead-dark">
	  		<th>NO</th>
	  		<th>ID </th>
	  		<th>ID MUNUCIPIO</th>
	  		<th>NARAN POSTO</th>
	  		<th colspan="2">ASAUN</th>
	  		</thead>
	  	</tr>
	  	<?php 
	  	$no =1;
	  	foreach ($t_posto as $pos):
	  	 ?>
	  	 <tr>
	  	 	<td width="20px"><?php echo $no++ ?></td>
	  	 	<td><?php echo $pos->code_posto?></td>
	  	 	<td><?php echo $pos->code?></td>
	  	 	<td><?php echo $pos->nrn_posto?></td>
	  	 	<td width="20px"><?php echo anchor('administrator/posto/update/'.$pos->id,'<div class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></div>')?></td>

	  	 	<td width="20px"><?php echo anchor('administrator/posto/delete/'.$pos->id,'<div class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></div>')?></td>
	   	 </tr>
	  	 	<?php endforeach; ?>
	  </table>
</div>