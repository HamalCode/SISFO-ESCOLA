<div class="container-fluid">
		<div class="alert alert-info bg-info text-white text-center" role="alert">
	   <!--  <i class="fas fa-university"></i> --> <b>RELATORIO REGISTU POSTO ADMINISTRATIVU</b>
	  </div>
	  <?php echo anchor('administrator/posto/print',' <button class="btn btn-sm btn-secondary mb-3"><i class="fa fa-print"></i> Print Data</button>') ?>
	  <?php echo anchor('administrator/posto/pdf',' <button class="btn btn-sm btn-warning mb-3"><i class="fa fa-file-pdf"></i> Export PDF</button>') ?>

	  <table class="table table-bordered table-striped table-hover">
	  	<tr>
	  		<thead class="thead-dark">
	  		<th>NO</th>
	  		<th class="text-center">ID POSTO</th>
	  		<th class="text-center">NARAN POSTO</th>
	  			</thead>
	  	</tr>
	  	<?php 
	  	$no =1;
	  	foreach ($t_posto as $pos):
	  	 ?>
	  	 <tr>
	  	 	<td width="20px"><?php echo $no++ ?></td>
	  	 	<td class="text-center"><?php echo $pos->code_posto?></td>
	  	 	<td class="text-center"><?php echo $pos->nrn_posto?></td>
	  	 	 </tr>
	  	 	<?php endforeach; ?>
	  </table>
</div>