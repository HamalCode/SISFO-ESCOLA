<div class="container-fluid">
	<div class="alert alert-info bg-info text-white text-center" role="alert">
	<center><b>RELATORIO POSTO ADMINISTRATIVU</b></center>   <br>	
</div>
	     


	  <table  align="center" border="1" width="70%">
	  	<tr>
	  		<thead class="thead-dark">
	  		<th>NO</th>
	  		<th  class="text-center">ID POSTO</th>
	  		<th  class="text-center">NARAN POSTO</th>
	  	   </thead>
	  	</tr>
	  	<?php 
	  	$no =1;
	  	foreach ($t_posto as $pos):
	  	 ?>
	  	 <tr>
	  	 	<td width="20px"><?php echo $no++ ?></td>
	  	 	<td class="text-center"><?php echo $pos->code_posto?></td>
	  	 	<td  class="text-center"><?php echo $pos->nrn_posto?></td>
	  	 	
	  	 </tr>
	  	 	<?php endforeach; ?>
	  </table>
	
	  
</div>
<script type="text/javascript">
     window.print();
   </script>