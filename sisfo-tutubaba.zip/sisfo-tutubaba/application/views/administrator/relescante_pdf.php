<center><H2>RELATORIO ESCOLA ANTERIOR</H2></center><br><hr><html>
<head><link rel="stylesheet" type="text/css" href="style.css">
	<title></title>
</head><body>
	<table align="center"cellspacing='0' border="1" width="60%">
	
			<tr>
			<th bgcolor="silver">NO</th>
			<th bgcolor="silver">ID ESCOLA ANTERIOR</th>
			<th bgcolor="silver">NARAN ESCOLA ANTERIOR</th>			
			</tr>
		</tr>
			<?php 
		$no=1;
		foreach ($t_esc_ante as $esc) : ?>
			<tr>
				    <td class="center"><?php echo $no++ ?></td>
				    <td class="center"><?php echo $esc->code_escante ?></td>
				     <td class="center"><?php echo $esc->nrn_escante ?></td>										
			</tr>
		<?php endforeach; ?>
		
	</table>
</body></html>