<center><H2>RELATORIO REGISTU SUCO</H2></center><br><hr><html>
<head><link rel="stylesheet" type="text/css" href="style.css">
	<title></title>
</head><body>
	<table align="center"cellspacing='0' border="1" width="60%">
	
			<tr>
			<th bgcolor="silver">NO</th>
			<th bgcolor="silver">ID SUCO</th>
			<th bgcolor="silver">NARAN SUCO</th>			
			</tr>
		</tr>
			<?php 
		$no=1;
		foreach ($t_suco as $suc) : ?>
			<tr>
				    <td class="center"><?php echo $no++ ?></td>
				    <td class="center"><?php echo $suc->id_suco ?></td>
				     <td class="center"><?php echo $suc->nrn_suco ?></td>										
			</tr>
		<?php endforeach; ?>
		
	</table>
</body></html>