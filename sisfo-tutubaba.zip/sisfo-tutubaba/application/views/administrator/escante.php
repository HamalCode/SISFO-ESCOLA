<div class="container-fluid">
		<div class="alert alert-info bg-info text-white" role="alert">
	    <i class="fas fa-university"></i> <b>DADUS ESCOLA ANTERIOR</b>
	  </div>
	  <?php echo $this->session->flashdata('mensagem') ?>
	  <?php echo anchor('administrator/escante/amenta_escante',' <button class="btn btn-sm btn-warning mb-3"><i class="fas fa-plus fa-sm"></i> Registu Escante</button>') ?>
	 

	  <table class="table table-bordered table-striped table-hover">
	  	<tr>
	  		<thead class="thead-dark">
	  		<th>NO</th>
	  		<th>CODE ESCOLA-ANTERIOR</th>
	  		<th>ID SUCO</th>
	  		<th>NARAN  ESCO-ANTERIOR</th>
	  		<th colspan="2">ASAUN</th>
	  		</thead>
	  	</tr>
	  	<?php 
	  	$no =1;
	  	foreach ($t_esc_ante as $esc):
	  	 ?>
	  	 <tr>
	  	 	<td width="20px"><?php echo $no++ ?></td>
	  	 	<td><?php echo $esc->code_escante?></td>
	  	 	<td><?php echo $esc->code_suco?></td>
	  	 	<td><?php echo $esc->nrn_escante?></td>
	  	 	<td width="20px"><?php echo anchor('administrator/escante/update/'.$esc->id,'<div class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></div>')?></td>

	  	 	<td width="20px"><?php echo anchor('administrator/escante/delete/'.$esc->id,'<div class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></div>')?></td>
	  	 </tr>
	  	 	<?php endforeach; ?>
	  </table>
</div>