<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo base_url('administrator/dashboard') ?>">
        <div class="sidebar-brand-icon">
          <i class="fas fa-university"></i>
        </div>
        <div class="sidebar-brand-text mx-1">SI-EBC TATUTABA</div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url('administrator/dashboard') ?>">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>
  <!-- Nav Item - Pages Collapse Menu master input -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
          <i class="fas fa-keyboard"></i>
          <span>MASTER INPUT</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Input Dadus EBC-HERA:</h6>
            <a class="collapse-item" href="<?php echo base_url('administrator/estudante') ?>">INPUT ESTUDANTE</a>
               <a class="collapse-item" href="<?php echo base_url('administrator/municipio') ?>">INPUT MUNICIPIO</a>
            <a class="collapse-item" href="<?php echo base_url('administrator/posto') ?>">INPUT POSTO</a>
            <a class="collapse-item" href="<?php echo base_url('administrator/suco') ?>"> INPUT SUCO</a>
            <a class="collapse-item" href="<?php echo base_url('administrator/escante') ?>">INPUT ESC-ANTERIOR</a>
            </div>
        </div>
      </li>


<!-- nav-item -prosesu menu -->
         <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('administrator/prosesu') ?>">
          <i class="fas fa-book"></i>
          <span>PROSESU DADUS</span></a>
      </li>
<!-- nav-item -prosesu menu -->


      <!-- Nav Item - Pages Collapse Menu Outpu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
          <i class="fas fa-outdent"></i>
          <span>OUTPUT</span>
        </a>
        <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Output Dadus EBC-HERA:</h6>
             <a class="collapse-item" href="<?php echo base_url('administrator/result_estudante') ?>">DADUS ESTUDANTE</a>
             <a class="collapse-item" href="<?php echo base_url('administrator/result_municipio') ?>">DADUS MUNICIPIO</a>
            <a class="collapse-item" href="<?php echo base_url('administrator/result_posto') ?>">DADUS POSTO</a>
            <a class="collapse-item" href="<?php echo base_url('administrator/result_suco') ?>"> DADUS SUCO</a>
            <a class="collapse-item" href="<?php echo base_url('administrator/result_escante') ?>"">DADUS ESC-ANTERIOR</a>
           
           </div>
        </div>
      </li>


      <!-- Nav Item - Utilities Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-user"></i>
          <span>USER</span>
        </a>
        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Setting User:</h6>
            <a class="collapse-item" href="<?php echo base_url('administrator/user') ?>">EDIT USER</a>
           
          </div>
        </div>
      </li>
      <!-- Nav Item - Pages Collapse Menu -->
      

      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('administrator/auth/logout') ?>">
          <i class="fas fa-sign-out-alt"></i>
          <span>LOGOUT</span></a>
      </li>
    <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          

          <!-- Topbar Search -->
         <img src="<?php echo base_url('assets/uploads/edu.jpg') ?> " width='75'>
     <strong>
      <font size="3"> SISTEMA  INFORMASAUN  REJISTU ESTUDANTE  FOUN
        IHA ENSINO BÁSICO FILIAL N<sup>o</sup>519 TATUTABA.</font>
      </strong>
          <!-- Topbar Navbar -->
          
        </nav>