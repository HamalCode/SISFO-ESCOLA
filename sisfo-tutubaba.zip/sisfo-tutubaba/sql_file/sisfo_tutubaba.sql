-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 18, 2021 at 03:13 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sisfo_tutubaba`
--

-- --------------------------------------------------------

--
-- Table structure for table `t_esc_ante`
--

CREATE TABLE `t_esc_ante` (
  `id` int(11) NOT NULL,
  `code_escante` char(10) NOT NULL,
  `code_suco` char(50) NOT NULL,
  `nrn_escante` char(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `t_esc_ante`
--

INSERT INTO `t_esc_ante` (`id`, `code_escante`, `code_suco`, `nrn_escante`) VALUES
(1, 'EP003', 'ST001', 'Escola Primaria Cailaco'),
(2, 'EP002', 'S001', 'Escola Primaria Balibo'),
(3, 'EP003', 'ST001', 'EBC Cailaco');

-- --------------------------------------------------------

--
-- Table structure for table `t_estudante`
--

CREATE TABLE `t_estudante` (
  `id` int(11) NOT NULL,
  `nre` int(11) NOT NULL,
  `code_escante` char(50) NOT NULL,
  `nrn_estudante` char(100) NOT NULL,
  `sexo` char(10) NOT NULL,
  `code` char(10) NOT NULL,
  `code_posto` varchar(12) NOT NULL,
  `code_suco` varchar(12) NOT NULL,
  `inan` char(100) NOT NULL,
  `aman` char(100) NOT NULL,
  `reli` varchar(100) NOT NULL,
  `hela_fatin` char(100) NOT NULL,
  `no_tfn` char(14) NOT NULL,
  `foto` varchar(50) NOT NULL,
  `obs` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `t_estudante`
--

INSERT INTO `t_estudante` (`id`, `nre`, `code_escante`, `nrn_estudante`, `sexo`, `code`, `code_posto`, `code_suco`, `inan`, `aman`, `reli`, `hela_fatin`, `no_tfn`, `foto`, `obs`) VALUES
(15, 12312400, 'EP001', 'Ana Baptista', 'Feto', 'DLI06', 'CR-01', 'ST001', 'Joana', 'Jose Goncalves', 'Katolika', 'Becora', '77543223', '152.jpeg', 'Diak los'),
(16, 1729773509, 'EP002', 'Marta Da costa', 'Feto', 'DLI06', 'VC-13', 'ST001', 'Joana Miranda', 'Jose Matos', 'Protestante', 'Bidau', '77543295', '142.jpeg', 'Diak '),
(17, 12312400, 'EP001', 'Jhon Costa Borges', 'Mane', 'DLI06', 'VC-13', 'ST001', 'Maria Filomena', 'Jose Goncalves', 'Katolika', 'Becora', '77543298', 'Freliaa4.jpg', 'DiaK'),
(18, 72638439, 'EP003', 'Marcos', 'Mane', 'BBNR04', 'ATB013', '2343', 'Maria Filomena', 'Covid Bareto', 'Katolika', 'Atabae', '77543295', '105.jpeg', 'Ladiak'),
(19, 1231242131, 'EP003', 'Ana Baptista', 'Feto', 'DLI06', 'CR-01', 'ST001', 'Astrazeneka da Costa', 'Jose Matos', 'Islam', 'Becora', '77543295', '153.jpeg', 'Documentus la kompletu'),
(20, 1520000001, 'EP002', 'Marta Da costa', 'Feto', 'DLI06', 'NF-05', 'LH2343', 'Josefa Charles', 'Afonso', 'Protestante', 'Lahane Ocidental', '77543291', '143.jpeg', 'Diak '),
(21, 1231240013, 'EP003', 'Januario Costa', 'Mane', 'BBNR04', 'ATB013', '2343', 'Abia Santos', 'Anjulino De Jesus', 'Protestante', 'Maliana VIla', '77543265', '93.jpeg', 'Documentus la kompletu'),
(22, 1729773512, 'EP003', 'Anastacia Baptista', 'Feto', 'DLI06', 'CR-01', 'ST001', 'Joana', 'Jose', 'Katolika', 'Bidau', '75645321', 'IMG_93291.jpg', 'Diak '),
(23, 1231224001, 'EP003', 'Madalena', 'Feto', 'DLI06', 'VC-13', 'LH2343', 'Agela Miranda', 'Natalino Jose', 'Katolika', 'Kuluhun', '75234523', '131.jpg', 'Documentus la kompletu'),
(24, 2147483647, 'EP003', 'Ana Baptista', 'Mane', 'BBNR04', 'CR-01', '2343', 'Joana', 'Jose Matos', 'Katolika', 'Becora', '77543223', '82.jpg', 'Ladiak');

-- --------------------------------------------------------

--
-- Table structure for table `t_municipio`
--

CREATE TABLE `t_municipio` (
  `id_municipio` int(11) NOT NULL,
  `code` char(10) NOT NULL,
  `nrn_municipio` char(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `t_municipio`
--

INSERT INTO `t_municipio` (`id_municipio`, `code`, `nrn_municipio`) VALUES
(5, 'CVL05', 'Covalima'),
(6, 'DLI06', 'Dili'),
(7, 'ERM07', 'Ermera'),
(8, 'LTM09', 'Lautem'),
(9, 'LIK08', 'Liquica'),
(10, 'MF11', 'Manufahi'),
(11, 'MT10', 'Manatuto'),
(12, 'OEC12', 'Oe-Cusse'),
(13, 'VQQ13', 'Viqueque'),
(15, 'AIL01', 'Aileu'),
(16, 'BCU03', 'Baucau'),
(17, 'BBNR04', 'Bobonaro'),
(18, 'ANR02', 'Ainaro');

-- --------------------------------------------------------

--
-- Table structure for table `t_posto`
--

CREATE TABLE `t_posto` (
  `id` int(11) NOT NULL,
  `code_posto` char(10) NOT NULL,
  `code` char(50) NOT NULL,
  `nrn_posto` char(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `t_posto`
--

INSERT INTO `t_posto` (`id`, `code_posto`, `code`, `nrn_posto`) VALUES
(1, 'CR-01', 'CVL05', 'Cristo Rei'),
(2, 'VC-13', 'DLI06', 'Vera Cruz'),
(3, 'NF-05', 'DLI06', 'Nain feto'),
(4, 'ATB013', 'BBNR04', 'Atabae');

-- --------------------------------------------------------

--
-- Table structure for table `t_suco`
--

CREATE TABLE `t_suco` (
  `id` int(11) NOT NULL,
  `code_suco` char(10) NOT NULL,
  `code_posto` char(10) NOT NULL,
  `nrn_suco` char(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `t_suco`
--

INSERT INTO `t_suco` (`id`, `code_suco`, `code_posto`, `nrn_suco`) VALUES
(1, 'ST001', 'CR012', 'Cristo Rei'),
(2, '2343', 'CR-01', 'Masaur'),
(3, 'LH2343', 'CR-01', 'Lahane');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(40) NOT NULL,
  `level` enum('admin','user') NOT NULL,
  `blokir` enum('Y','N') NOT NULL,
  `id_session` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `email`, `level`, `blokir`, `id_session`) VALUES
(12, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'namessapinto@gmail.com', 'admin', 'N', 'd41d8cd98f00b204e9800998ecf8427e'),
(18, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'itsilvinoalbano@gmail.com', 'admin', 'N', 'd41d8cd98f00b204e9800998ecf8427e');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `t_esc_ante`
--
ALTER TABLE `t_esc_ante`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_estudante`
--
ALTER TABLE `t_estudante`
  ADD PRIMARY KEY (`id`),
  ADD KEY `nre` (`nre`);

--
-- Indexes for table `t_municipio`
--
ALTER TABLE `t_municipio`
  ADD PRIMARY KEY (`id_municipio`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `t_posto`
--
ALTER TABLE `t_posto`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_suco`
--
ALTER TABLE `t_suco`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `t_esc_ante`
--
ALTER TABLE `t_esc_ante`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `t_estudante`
--
ALTER TABLE `t_estudante`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `t_municipio`
--
ALTER TABLE `t_municipio`
  MODIFY `id_municipio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `t_posto`
--
ALTER TABLE `t_posto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `t_suco`
--
ALTER TABLE `t_suco`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
